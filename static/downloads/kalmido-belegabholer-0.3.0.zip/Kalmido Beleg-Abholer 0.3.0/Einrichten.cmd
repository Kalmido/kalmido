@echo off
rem Kalmido Beleg-Abholer - double-click: install (or update) for this Windows user, then the guided setup.
chcp 65001 >nul
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1" -Einrichten
echo.
pause
