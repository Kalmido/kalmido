# Kalmido Beleg-Abholer

Holt Rechnungen aus Web-Portalen (Amazon, Google, klarmobil) auf deinem Mac oder Windows-PC und gibt sie direkt an Kalmido (Einstellungen >
Integrationen > Beleg-Abholer) oder legt sie als PDF in den Ordner, den der Kalmido-Ordner-Wächter hochlädt. Die Anmeldung bei den Portalen machst du selbst, einmal im sichtbaren Browser; das
Programm merkt sich die Sitzung in einem eigenen Browserprofil und holt danach jede Nacht unsichtbar die neuen
Rechnungen. Passwörter werden nie gespeichert.

## Einrichten für Kollegen (Doppelklick, ohne Terminal-Kenntnisse)

Das Zip `kalmido-belegabholer-<Version>.zip` auspacken, dann

- **Mac:** `Einrichten.command` doppelklicken (beim ersten Mal: Rechtsklick > Öffnen, weil die Datei nicht aus dem
  App Store kommt),
- **Windows:** `Einrichten.cmd` doppelklicken (bei "Der Computer wurde durch Windows geschützt": Weitere Informationen >
  Trotzdem ausführen).

Das installiert alles nur für den eigenen Benutzer (keine Admin-Rechte; fehlt ein Python ab 3.10, holt es sich eins
über uv) und startet die geführte Einrichtung `belegabholer einrichten`: Einrichtungscode aus Kalmido einfügen,
Portale per Nummer wählen, je Konto einmal im Browserfenster anmelden (bei Google auf Wunsch mehrere Konten),
Nachtlauf an, erster Abruf. Die Einrichtung lässt sich jederzeit wiederholen (`belegabholer einrichten`).

## Einrichten im Terminal (einmal, in deinem eigenen Mac-Benutzer)

```bash
bash <ausgepackter Ordner>/install.sh
```

Das dauert ein paar Minuten (Python-Umgebung, Chromium). Danach:

```bash
~/.local/bin/belegabholer login amazon
```

Es öffnet sich ein Browserfenster mit Amazon. Dort anmelden (auch Code per SMS / App), "Angemeldet bleiben"
anhaken, dann das Fenster schließen. Das Programm prüft danach selbst, ob die Anmeldung sitzt.

Direkt mit Kalmido verbinden (empfohlen): in Kalmido unter Einstellungen > Integrationen > Beleg-Abholer einen
Abholer anlegen, den Einrichtungscode kopieren, dann

```bash
belegabholer verbinden
```

und den Code einfügen (so landet er nicht in der Shell-Historie). Ab dann gehen die Rechnungen direkt in deine
Dokumente in Kalmido, Kalmido zeigt je Portal den letzten Lauf und meldet sich selbst, wenn du dich neu anmelden
musst. Ohne Verbindung landen die PDFs im Ordner des Ordner-Wächters.

In einem neuen Terminal-Fenster reicht `belegabholer …` (der Ordner `~/.local/bin` wird beim Einrichten in den Pfad
aufgenommen).

## Befehle

| Befehl | Was er macht |
|---|---|
| `belegabholer einrichten` | geführte Einrichtung: Kalmido verbinden, Portale wählen, anmelden, Nachtlauf, erster Abruf |
| `belegabholer login amazon` | sichtbarer Browser zum Anmelden (auch nach "bitte neu einloggen") |
| `belegabholer login amazon --konto zweit` | zweites Konto beim selben Portal (eigenes Browserprofil) |
| `belegabholer run` | jetzt alle Portale abrufen (unsichtbar, nur neue Rechnungen) |
| `belegabholer run amazon --sichtbar` | ein Portal abrufen und dabei zusehen (Fehlersuche) |
| `belegabholer status` | Stand je Portal: letzter Lauf, geholt, Bestellungen noch ohne Rechnung, Nachtlauf |
| `belegabholer ordner [PFAD\|auto]` | Ablage-Ordner zeigen oder setzen (`auto` = Ordner-Wächter) |
| `belegabholer nachtlauf an\|aus` | nächtlichen Abruf an- oder ausschalten |
| `belegabholer rezepte [--holen]` | vorhandene Rezepte und ihre Versionen (`--holen`: jetzt neuere aus Kalmido holen) |
| `belegabholer login google --konto buero` | weiteres Google-Konto (jedes Konto eigenes Browserprofil) |
| `belegabholer verbinden [CODE]` | direkt mit Kalmido verbinden (Einrichtungscode; ohne CODE wird er abgefragt) |
| `belegabholer trennen` | Kalmido-Verbindung lösen, wieder in den Ordner ablegen |

## Was passiert nachts

- Mac: launchd, Windows: die Aufgabenplanung ("Kalmido Beleg-Abholer", nur im eigenen Benutzer) startet den Abruf
  einmal pro Nacht. Unter Windows wird ein verpasster Lauf nicht nachgeholt; der nächste holt 40 Tage zurück.
- Mit Kalmido-Verbindung fragt jeder Lauf zuerst nach neueren Rezepten (zentral verteilt, siehe unten).
- Zeit: Stunde 3, Minute beim Einrichten zufällig gewählt, dazu jedes Mal bis zu 25 Minuten zufällige Wartezeit.
  Schläft der Mac, läuft der Abruf beim Aufwachen.
- Zwischen den Seiten wartet das Programm zufällig 2,5 bis 7 Sekunden, höchstens 120 neue Rechnungen pro Nacht
  (der Rest folgt in der nächsten Nacht).
- Erster Lauf: laufendes Jahr und Vorjahr (`erster_lauf_jahre` in den Einstellungen). Danach: die letzten 40 Tage
  plus alle Bestellungen, die noch auf eine Rechnung warten.
- Amazon-Bestellungen ohne Rechnung (Händler hat sie noch nicht hochgeladen) werden gemerkt und 60 Nächte lang
  erneut geprüft.
- Dateiname: `Datum_Portal_Nummer.pdf`, z. B. `2026-10-03_Amazon_302-1234567-1234567.pdf`; zweite Rechnung einer
  Bestellung `…-2.pdf`, Gutschriften `…_Gutschrift.pdf`. Gleiche Datei zweimal (gleicher Hash) wird nur einmal abgelegt.
- Läuft die Anmeldung ab oder passt ein Rezept nicht mehr: Mitteilung am Mac und - mit Kalmido-Verbindung - eine
  Meldung von Kalmido (Neuigkeiten + Push), sonst (wenn eingerichtet) ein ntfy-Push; jeweils mit dem Befehl zum
  Beheben, z. B. `belegabholer login amazon`.
- Mit Kalmido-Verbindung: ein in Kalmido ausgeschaltetes Portal wird gar nicht erst geöffnet. Ist Kalmido nicht
  erreichbar, warten die PDFs in `warteschlange/` und gehen beim nächsten Lauf raus. Wurde der Abholer in Kalmido
  getrennt (oder dein Passwort geändert), hält der Lauf an und meldet `belegabholer verbinden`.

## Wo was liegt

Alles in `~/Library/Application Support/Kalmido Beleg-Abholer/` (Mac) bzw. `%APPDATA%\Kalmido Beleg-Abholer\`
(Windows; das Programm selbst unter `%LOCALAPPDATA%\Kalmido Beleg-Abholer\`), nur für deinen Benutzer lesbar:

- `einstellungen.json` - Ablage, Zeitraum, Pausen, Portale und Konten
- `profile/<portal>-<konto>/` - die Browserprofile mit den Anmeldungen (nie weitergeben)
- `zustand/<portal>-<konto>.json` - was schon geholt wurde (Nummer + Datei-Hash) und was noch fehlt
- `status.json` - letzter Lauf je Portal (mit Kalmido-Verbindung auch dorthin gemeldet)
- `kalmido.json` - Adresse + Schlüssel des Abholers aus dem Einrichtungscode (Rechte 600, nie im Protokoll)
- `warteschlange/` - PDFs, die Kalmido gerade nicht erreicht haben
- `belegabholer.log` - Protokoll nur mit Zahlen, ohne Bestellnummern, Beträge oder Dateinamen
- `rezepte/` - zentral aus Kalmido verteilte Rezepte, je Rezept `<id>.py` + `<id>.sig.json`; benutzt wird eins nur mit
  gültiger Signatur, und nur wenn es neuer ist als das eingebaute
- `ntfy.env` - optional: `NTFY_URL`, `NTFY_TOPIC`, `NTFY_TOKEN` für Push-Meldungen (Rechte 600)

Ablage: ohne Einstellung der Ordner aus der Konfiguration des Kalmido-Ordner-Wächters (bei mehreren Eingängen der
mit "Beleg"/"Rechnung" im Namen, sonst der erste), gibt es den nicht: `~/Belege/Eingang`.
