#!/bin/bash
# Kalmido Beleg-Abholer - double-click in the Finder: install (or update) for this Mac user, then the guided setup.
# The first time macOS may ask: right click > Open (the file is not from the App Store).
cd "$(dirname "$0")" || exit 1
bash ./install.sh && "$HOME/.local/bin/belegabholer" einrichten
echo
read -r -p "Fertig. Enter schließt dieses Fenster. " _
