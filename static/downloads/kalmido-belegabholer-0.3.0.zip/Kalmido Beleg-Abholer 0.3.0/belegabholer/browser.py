"""One persistent Chromium profile per portal account (Playwright). The profile holds the portal's cookies, so a
login made once in the visible browser carries the invisible night runs. Profiles stay in the settings folder,
mode 700, never in a repo or a log."""
import contextlib
import os
from pathlib import Path

UA_HINT_ARGS = ["--disable-blink-features=AutomationControlled", "--no-first-run", "--no-default-browser-check"]


class ProfilBelegt(Exception):
    """The profile is open in another browser (e.g. the login window is still open)."""


def _belegt(e) -> bool:
    return "ProcessSingleton" in str(e) or "already in use" in str(e) or "SingletonLock" in str(e)


@contextlib.contextmanager
def profil(path: Path, sichtbar: bool = False, kanal: str = ""):
    """kanal "chrome": the installed Google Chrome (Google's own sign-in refuses Playwright's Chromium more often);
    without Chrome on this computer it falls back to Playwright's Chromium."""
    from playwright.sync_api import Error as PwError, sync_playwright

    path.mkdir(parents=True, exist_ok=True)
    os.chmod(path, 0o700)
    opts = dict(headless=not sichtbar, accept_downloads=True, locale="de-DE", timezone_id="Europe/Berlin",
                viewport=None if sichtbar else {"width": 1366, "height": 900}, args=UA_HINT_ARGS)
    with sync_playwright() as pw:
        ctx = None
        if kanal:
            try:
                ctx = pw.chromium.launch_persistent_context(str(path), channel=kanal, **opts)
            except PwError as e:
                if _belegt(e):
                    raise ProfilBelegt(str(path.name)) from None
                ctx = None     # that browser is not installed here: Playwright's Chromium
        if ctx is None:
            try:
                ctx = pw.chromium.launch_persistent_context(str(path), **opts)
            except PwError as e:
                if _belegt(e):
                    raise ProfilBelegt(str(path.name)) from None
                raise
        try:
            ctx.set_default_timeout(45_000)
            yield ctx
        finally:
            with contextlib.suppress(Exception):
                ctx.close()


def kanal(cls, cfg: dict) -> str:
    """The browser of a recipe; settings portale.<id>.kanal overrides it ("" = Playwright's Chromium, e.g. tests)."""
    return str(((cfg.get("portale") or {}).get(cls.ID) or {}).get("kanal", cls.KANAL) or "")


def erste_seite(ctx):
    return ctx.pages[0] if ctx.pages else ctx.new_page()
