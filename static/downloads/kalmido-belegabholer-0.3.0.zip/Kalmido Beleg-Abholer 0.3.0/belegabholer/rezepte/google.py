"""Google (payments center): invoices / receipts of Google services (Workspace, Google One, Ads, Cloud) - #3454.

Version 0.1.0 is built against an artificial mock page only: the first real run should be watched once
(`belegabholer run google --sichtbar`). If Google shows the invoices on another page, the list page can be set without
a new version: settings portale.google.liste_url. Several Google accounts = several accounts here (each its own
browser profile, `belegabholer login google --konto buero`). Uses the installed Google Chrome when there is one: Google's
sign-in turns away automated Chromium more often.
"""
from belegabholer.liste import ListenRezept


class Rezept(ListenRezept):
    ID = "google"
    NAME = "Google"
    VERSION = "0.1.0"
    HINWEIS = "Workspace, Google One, Ads, Cloud; mehrere Konten möglich"
    MEHRERE_KONTEN = True
    KANAL = "chrome"
    BASIS_URL = "https://payments.google.com"
    START_URL = "/gp/w/home/activity"
    LISTE_PFAD = "/gp/w/home/activity"
    ZEILEN = "[role=row], [role=listitem], tr, li.transaction, div.b3-transaction"
    PDF_RE = r"\.pdf(\?|$)|/download|apis-secure/doc|documentdownload|/invoice"
    PDF_TEXT_RE = r"\bpdf\b|rechnung|beleg herunterladen|herunterladen|download|invoice|receipt"
    NUMMER_RE = r"(?:Rechnungs?(?:nummer|-?nr\.?)|Beleg(?:nummer)?|Transaktions-?ID|Invoice(?: number)?)\s*:?\s*([A-Z0-9][A-Z0-9.-]{3,})"
    LOGIN_URL_RE = r"accounts\.google\.com|ServiceLogin|/signin"
    LEER_RE = r"keine (transaktionen|aktivitäten|rechnungen|belege|dokumente)|no (transactions|activity|invoices|documents)"
