"""Amazon.de: invoices from the order history ("Meine Bestellungen").

Path: order list per year (/your-orders/orders?timeFilter=year-YYYY&startIndex=N, 10 per page) -> per order its
invoice list (the "Rechnung" popover, own URL) -> the PDF links in it ("Rechnung 1", "Gutschrift 1", ...).
An order without a PDF link (seller has not uploaded it yet, "Rechnung anfordern") is reported with url=None.

The selectors are kept loose on purpose (order number by pattern, date by German month names, invoice links by
"invoice" in the URL), so small layout changes do not break it. Settings: portale.amazon.basis_url (default
https://www.amazon.de; the tests use a local mock).
"""
import re
from datetime import date

from belegabholer.rezept import AnmeldungAbgelaufen, Basis, Beleg, RezeptKaputt

MONATE = {m: i + 1 for i, m in enumerate(["januar", "februar", "märz", "april", "mai", "juni", "juli", "august",
                                           "september", "oktober", "november", "dezember"])}
MONATE.update({"maerz": 3, "jan.": 1, "feb.": 2, "mär.": 3, "apr.": 4, "aug.": 8, "sept.": 9, "sep.": 9, "okt.": 10,
               "nov.": 11, "dez.": 12})
ORDER_RE = re.compile(r"\b((?:\d{3}|D01)-\d{7}-\d{7})\b")
DATE_RE = re.compile(r"\b(\d{1,2})\.\s*([A-Za-zäÄ]+\.?)\s+(\d{4})\b")
PAGE_SIZE = 10

# runs in the page: every order card -> its text and every URL in it (links + popover data) that mentions "invoice"
CARDS_JS = """
() => {
  const cards = Array.from(document.querySelectorAll('.order-card, .js-order-card, #ordersContainer > .order, .a-box-group.order'));
  const seen = new Set();
  return cards.filter(c => { if (seen.has(c)) return false; seen.add(c);
      return !cards.some(o => o !== c && o.contains(c)); })   // innermost duplicates out
    .map(c => {
      const urls = [];
      c.querySelectorAll('a[href]').forEach(a => { const h = a.getAttribute('href');
        if (/invoice/i.test(h)) urls.push(h); });
      c.querySelectorAll('[data-a-popover]').forEach(e => {
        try { const d = JSON.parse(e.getAttribute('data-a-popover')); if (d.url && /invoice/i.test(d.url)) urls.push(d.url); }
        catch (err) {} });
      return {text: c.innerText || c.textContent || '', urls};
    });
}
"""

LINKS_JS = """
() => Array.from(document.querySelectorAll('a[href]')).map(a => ({href: a.href, text: (a.innerText || a.textContent || '').trim()}))
"""


def deutsches_datum(text: str):
    for d, m, y in DATE_RE.findall(text):
        mon = MONATE.get(m.lower())
        if mon:
            try:
                return date(int(y), mon, int(d))
            except ValueError:
                continue
    return None


def ist_pdf_link(href: str, text: str) -> bool:
    h = href.lower()
    if "print.html" in h or "summary" in h:   # order summary, an HTML page, not an invoice
        return False
    return h.endswith(".pdf") or ".pdf?" in h or "/documents/download/" in h or "invoice/download" in h \
        or ("download" in h and re.search(r"rechnung|gutschrift|invoice", text, re.I) is not None)


class Rezept(Basis):
    ID = "amazon"
    NAME = "Amazon"
    VERSION = "1.0.0"
    START_URL = "/your-orders/orders"
    BASIS_URL = "https://www.amazon.de"
    HINWEIS = "Rechnungen aus 'Meine Bestellungen'"
    MEHRERE_KONTEN = True

    def liste_url(self, jahr: int, start: int) -> str:
        return self.url(f"/your-orders/orders?timeFilter=year-{jahr}&startIndex={start}")

    def _pruefe_anmeldung(self, page):
        u = page.url.lower()
        if "validatecaptcha" in u or page.locator("form[action*='validateCaptcha']").count():
            raise AnmeldungAbgelaufen("Sicherheitsabfrage (Captcha)")
        if "/ap/signin" in u or "/ap/mfa" in u or "/ap/cvf" in u or page.locator("#ap_email, #ap_password, form[name='signIn']").count():
            raise AnmeldungAbgelaufen("Anmeldung verlangt")

    def angemeldet(self, page) -> bool:
        page.goto(self.url(self.START_URL), wait_until="domcontentloaded")
        self.pause(0.5)
        try:
            self._pruefe_anmeldung(page)
        except AnmeldungAbgelaufen as e:
            if "Captcha" in str(e):
                raise
            return False
        return True

    def belege(self, page, seit: date, erledigt=lambda gruppe, datum: False):
        pop = page.context.new_page()
        try:
            for jahr in range(date.today().year, seit.year - 1, -1):
                start = 0
                while True:
                    page.goto(self.liste_url(jahr, start), wait_until="domcontentloaded")
                    self.pause()
                    self._pruefe_anmeldung(page)
                    karten = page.evaluate(CARDS_JS)
                    if not karten:
                        body = (page.locator("body").inner_text() or "").lower()
                        if start > 0 or "keine bestellungen" in body or "0 bestellungen" in body:
                            break
                        raise RezeptKaputt("Bestellliste ohne erkennbare Bestellungen")
                    zu_alt = False
                    for k in karten:
                        m = ORDER_RE.search(k["text"])
                        datum = deutsches_datum(k["text"])
                        if not m or not datum:
                            raise RezeptKaputt("Bestellnummer oder Datum nicht gefunden")
                        nr = m.group(1)
                        if datum < seit:
                            zu_alt = True
                            continue
                        if erledigt(nr, datum):
                            continue
                        yield from self._rechnungen(pop, nr, datum, k["urls"])
                    if zu_alt or len(karten) < PAGE_SIZE or not self._weiter(page):
                        break
                    start += PAGE_SIZE
        finally:
            pop.close()

    def _weiter(self, page) -> bool:
        nxt = page.locator("ul.a-pagination li.a-last:not(.a-disabled) a")
        return nxt.count() > 0

    def _rechnungen(self, pop, nr: str, datum: date, urls):
        kandidaten = list(dict.fromkeys(urls)) or [f"/gp/shared-cs/ajax/invoice/invoice.html?orderId={nr}"]
        pdfs = []
        for u in kandidaten:
            if ist_pdf_link(u, "rechnung"):
                pdfs.append({"href": self.url(u), "text": "Rechnung"})
                continue
            pop.goto(self.url(u), wait_until="domcontentloaded")
            self.pause(0.6)
            self._pruefe_anmeldung(pop)
            pdfs += [l for l in pop.evaluate(LINKS_JS) if ist_pdf_link(l["href"], l["text"])]
            if pdfs:
                break
        seen, n = set(), 0
        for l in pdfs:
            if l["href"] in seen:
                continue
            seen.add(l["href"])
            n += 1
            art = "Gutschrift" if re.search(r"gutschrift|credit", l["text"], re.I) else "Rechnung"
            nummer = nr if n == 1 else f"{nr}-{n}"
            yield Beleg(schluessel=f"{nr}#{n}", nummer=nummer, datum=datum, url=l["href"], gruppe=nr, art=art)
        if n == 0:
            yield Beleg(schluessel=nr, nummer=nr, datum=datum, url=None, gruppe=nr)

    def laden(self, page, beleg: Beleg) -> bytes:
        self.pause(0.5)
        r = page.context.request.get(beleg.url, timeout=60_000)
        body = r.body()
        if r.status in (401, 403) or (not body.startswith(b"%PDF") and b"ap_email" in body[:200000]):
            raise AnmeldungAbgelaufen("Anmeldung beim Download verlangt")
        if r.status != 200:
            raise RezeptKaputt(f"Download HTTP {r.status}")
        return body


