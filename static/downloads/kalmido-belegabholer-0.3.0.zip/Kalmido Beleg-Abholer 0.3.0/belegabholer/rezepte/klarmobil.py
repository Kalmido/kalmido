"""klarmobil: the monthly bills from the customer area "Mein klarmobil" - #3454.

Version 0.1.0 is built against an artificial mock page only: the first real run should be watched once
(`belegabholer run klarmobil --sichtbar`). Another bills page can be set without a new version: settings
portale.klarmobil.liste_url. Several contracts with different logins = several accounts (`--konto`).
"""
from belegabholer.liste import ListenRezept


class Rezept(ListenRezept):
    ID = "klarmobil"
    NAME = "klarmobil"
    VERSION = "0.1.0"
    HINWEIS = "Mobilfunk-Rechnungen aus Mein klarmobil"
    MEHRERE_KONTEN = True
    BASIS_URL = "https://www.klarmobil.de"
    START_URL = "/mein-klarmobil"
    LISTE_PFAD = "/mein-klarmobil/rechnungen"
    ZEILEN = "tr, li, .invoice, .rechnung, [data-testid*=invoice]"
    PDF_RE = r"\.pdf(\?|$)|/download|/rechnung|/invoice|/document"
    LOGIN_URL_RE = r"/login|/anmelden|/sso|/auth"
