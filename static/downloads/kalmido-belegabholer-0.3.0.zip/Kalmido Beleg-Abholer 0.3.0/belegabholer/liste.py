"""ListenRezept (#3454): the base for portals that show a plain list of invoices with a PDF link per row
(customer accounts of phone companies, Google payments, ...). A recipe then only names its pages and patterns:

    LISTE_PFAD    the page with the invoice list (relative to BASIS_URL; settings portale.<id>.liste_url overrides it)
    ZEILEN        CSS selector of one invoice row (searched in the page AND its frames, Google shows the list in one)
    PDF_RE        a link whose URL matches this, or whose text matches PDF_TEXT_RE, is the invoice PDF
    NUMMER_RE     the invoice number in the row text (group 1); missing = a stable key from date + link
    LOGIN_URL_RE  a URL matching this means "logged out" (also: a visible password field)
    LEER_RE       the text of an empty list ("keine Rechnungen"), so an empty list is no broken recipe
    WEITER        CSS selector of the "next page" link (optional)

Dates: German numeric (03.10.2026), German month names (3. Okt. 2026 / 3. Oktober 2026) and ISO (2026-10-03).
A row without a PDF link is reported with url=None (checked again in later nights).
"""
import hashlib
import re
from datetime import date
from urllib.parse import urljoin, urlsplit, urlunsplit

from .rezept import AnmeldungAbgelaufen, Basis, Beleg, RezeptKaputt

MONATE = {m: i + 1 for i, m in enumerate(["januar", "februar", "märz", "april", "mai", "juni", "juli", "august",
                                           "september", "oktober", "november", "dezember"])}
MONATE.update({"maerz": 3, "jan": 1, "feb": 2, "mär": 3, "mrz": 3, "apr": 4, "jun": 6, "jul": 7, "aug": 8, "sep": 9,
               "sept": 9, "okt": 10, "nov": 11, "dez": 12})
NUM_DATE_RE = re.compile(r"\b(\d{1,2})\.(\d{1,2})\.(\d{4}|\d{2})\b")
NAME_DATE_RE = re.compile(r"\b(\d{1,2})\.\s*([A-Za-zäÄ]{3,9})\.?\s+(\d{4})\b")
ISO_DATE_RE = re.compile(r"\b(\d{4})-(\d{2})-(\d{2})\b")

ZEILEN_JS = """
(sel) => {
  const rows = Array.from(document.querySelectorAll(sel));
  return rows.filter(r => !rows.some(o => o !== r && r.contains(o)))   // innermost rows only
    .map(r => ({text: (r.innerText || r.textContent || '').trim(),
                links: Array.from(r.querySelectorAll('a[href]')).map(a => ({
                  href: a.href, text: ((a.innerText || a.textContent || '') + ' ' + (a.getAttribute('aria-label') || '')
                        + ' ' + (a.getAttribute('title') || '') + ' ' + (a.getAttribute('download') !== null ? 'pdf' : '')).trim()}))}));
}
"""
PASSWORT_JS = """
() => Array.from(document.querySelectorAll('input[type=password]')).some(e => e.offsetParent !== null)
"""


def datum_aus(text: str):
    """The first date in a text (German numeric, German month name or ISO), else None."""
    kand = []
    for m in NUM_DATE_RE.finditer(text):
        d, mo, y = int(m.group(1)), int(m.group(2)), int(m.group(3))
        kand.append((m.start(), y + 2000 if y < 100 else y, mo, d))
    for m in NAME_DATE_RE.finditer(text):
        mo = MONATE.get(m.group(2).lower().rstrip("."))
        if mo:
            kand.append((m.start(), int(m.group(3)), mo, int(m.group(1))))
    for m in ISO_DATE_RE.finditer(text):
        kand.append((m.start(), int(m.group(1)), int(m.group(2)), int(m.group(3))))
    for _, y, mo, d in sorted(kand):
        try:
            return date(y, mo, d)
        except ValueError:
            continue
    return None


def ohne_query(href: str) -> str:
    s = urlsplit(href)
    return urlunsplit((s.scheme, s.netloc, s.path, "", ""))


class ListenRezept(Basis):
    LISTE_PFAD = "/"
    ZEILEN = "tr, li"
    PDF_RE = r"\.pdf(\?|$)|/download|/invoice|/rechnung"
    PDF_TEXT_RE = r"\bpdf\b|rechnung herunterladen|herunterladen|download"
    NUMMER_RE = r"(?:Rechnungs?(?:nummer|-?nr\.?)|Beleg(?:nummer)?|Invoice(?: number)?)\s*:?\s*([A-Z0-9][A-Z0-9-]{3,})"
    LOGIN_URL_RE = r"/login|/signin|/anmelden"
    LEER_RE = r"keine (rechnungen|belege|transaktionen|dokumente)|no (invoices|transactions|documents)"
    GUTSCHRIFT_RE = r"gutschrift|erstattung|refund|credit"
    WEITER = ""
    MAX_SEITEN = 30

    # ---- pages ----
    def liste_url(self) -> str:
        return self.portal_cfg.get("liste_url") or self.url(self.LISTE_PFAD)

    def _pruefe_anmeldung(self, page):
        if re.search(self.LOGIN_URL_RE, page.url, re.I):
            raise AnmeldungAbgelaufen("Anmeldung verlangt")
        try:
            if page.evaluate(PASSWORT_JS):
                raise AnmeldungAbgelaufen("Anmeldung verlangt")
        except AnmeldungAbgelaufen:
            raise
        except Exception:   # a page navigating away while asked: judged by the URL alone
            pass

    def angemeldet(self, page) -> bool:
        page.goto(self.liste_url(), wait_until="domcontentloaded")
        self.pause(0.5)
        try:
            self._pruefe_anmeldung(page)
        except AnmeldungAbgelaufen:
            return False
        return True

    def _zeilen(self, page):
        rows = []
        for fr in page.frames:
            try:
                rows += fr.evaluate(ZEILEN_JS, self.ZEILEN)
            except Exception:  # a frame of another origin that went away: skip it
                continue
        return rows

    def _text(self, page) -> str:
        out = []
        for fr in page.frames:
            try:
                out.append(fr.evaluate("() => document.body ? document.body.innerText : ''") or "")
            except Exception:
                continue
        return "\n".join(out)

    def _warte_auf_liste(self, page):
        """Lists that load late (single page apps): wait until a row or the empty text shows up (settings
        portale.<id>.warte_sek, default 15 s)."""
        for _ in range(int(self.portal_cfg.get("warte_sek", 15))):
            if self._zeilen(page) or re.search(self.LEER_RE, self._text(page), re.I):
                return
            page.wait_for_timeout(1000)

    def _weiter(self, page):
        if not self.WEITER:
            return None
        for fr in page.frames:
            try:
                loc = fr.locator(self.WEITER)
                if loc.count():
                    href = loc.first.get_attribute("href")
                    if href and not href.startswith("javascript"):
                        return urljoin(fr.url, href)
            except Exception:
                continue
        return None

    # ---- invoices ----
    def pdf_link(self, links):
        for l in links:
            if re.search(self.PDF_RE, l["href"], re.I) or re.search(self.PDF_TEXT_RE, l["text"], re.I):
                if not l["href"].lower().startswith("javascript"):
                    return l
        return None

    def nummer(self, text: str):
        m = re.search(self.NUMMER_RE, text, re.I)
        return m.group(1) if m else None

    def zeile_zu_beleg(self, z):
        datum = datum_aus(z["text"])
        if datum is None:
            return None     # a header or summary row
        link = self.pdf_link(z["links"])
        nr = self.nummer(z["text"])
        if not nr:
            basis = ohne_query(link["href"]) if link else z["text"][:200]
            nr = datum.strftime("%Y%m%d") + "-" + hashlib.sha1(basis.encode()).hexdigest()[:8]
        art = "Gutschrift" if re.search(self.GUTSCHRIFT_RE, z["text"], re.I) else "Rechnung"
        return Beleg(schluessel=nr, nummer=nr, datum=datum, url=link["href"] if link else None, gruppe=nr, art=art)

    def belege(self, page, seit: date, erledigt=lambda gruppe, datum: False):
        url = self.liste_url()
        for _ in range(self.MAX_SEITEN):
            page.goto(url, wait_until="domcontentloaded")
            self.pause()
            self._pruefe_anmeldung(page)
            self._warte_auf_liste(page)
            zeilen = self._zeilen(page)
            if not zeilen:
                if re.search(self.LEER_RE, self._text(page), re.I):
                    return
                raise RezeptKaputt("Rechnungsliste ohne erkennbare Zeilen")
            belege = [b for b in (self.zeile_zu_beleg(z) for z in zeilen) if b]
            if not belege:
                raise RezeptKaputt("Rechnungsliste ohne Datum in den Zeilen")
            zu_alt = False
            gesehen = set()
            for b in belege:
                if b.schluessel in gesehen:
                    continue
                gesehen.add(b.schluessel)
                if b.datum < seit:
                    zu_alt = True
                    continue
                if erledigt(b.gruppe, b.datum):
                    continue
                yield b
            nxt = None if zu_alt else self._weiter(page)
            if not nxt or nxt == url:
                return
            url = nxt

    def laden(self, page, beleg: Beleg) -> bytes:
        self.pause(0.5)
        r = page.context.request.get(beleg.url, timeout=60_000)
        body = r.body()
        if r.status in (401, 403) or (not body.startswith(b"%PDF") and re.search(
                rb"type=[\"']?password", body[:300000], re.I)):
            raise AnmeldungAbgelaufen("Anmeldung beim Download verlangt")
        if r.status != 200:
            raise RezeptKaputt(f"Download HTTP {r.status}")
        return body
