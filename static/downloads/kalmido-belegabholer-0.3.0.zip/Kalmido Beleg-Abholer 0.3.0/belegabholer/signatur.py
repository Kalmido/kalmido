"""Signed recipes (#3454): a recipe delivered from Kalmido is only ever run when an Ed25519 signature of the Kalmido
recipe key checks out. Built-in recipes (shipped inside the program) need no signature.

On disk next to a delivered recipe <settings>/rezepte/<id>.py lies <id>.sig.json:

    {"id": "amazon", "version": "1.1.0", "api": 1, "sha256": "<hex of the .py bytes>", "key": "<key id>", "sig": "<b64>"}

The signature covers nachricht(id, version, api, sha256) below, so a signed file can neither be swapped for other
code nor be renamed to another portal or version. The private key never leaves the release machine
(it signs with the release tooling's recipe signer); the public keys
are listed here. An empty list = no delivered recipe is accepted (safe default).
"""
import base64
import hashlib
import json
from pathlib import Path

# key id -> public key (raw 32 bytes, base64). Several entries allow a key change without breaking older helpers.
SCHLUESSEL = {
}

PREFIX = b"kalmido-belegabholer-rezept\n1\n"


class SignaturFehler(Exception):
    """The delivered recipe is unsigned, signed with an unknown key, or changed after signing."""


def nachricht(rid: str, version: str, api: int, sha256: str) -> bytes:
    return PREFIX + f"{rid}\n{version}\n{int(api)}\n{sha256}\n".encode("utf-8")


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def pruefen(quelle: bytes, sig: dict, schluessel: dict = None) -> dict:
    """Checks the signature document of a recipe source. -> sig (the signed id / version / api). Raises SignaturFehler."""
    schluessel = SCHLUESSEL if schluessel is None else schluessel
    try:
        rid, version, api = str(sig["id"]), str(sig["version"]), int(sig["api"])
        kid, raw = str(sig["key"]), base64.b64decode(sig["sig"], validate=True)
    except (KeyError, TypeError, ValueError):
        raise SignaturFehler("Signatur unvollständig") from None
    if sig.get("sha256") != sha256(quelle):
        raise SignaturFehler("Rezept nach dem Signieren verändert")
    pub = schluessel.get(kid)
    if not pub:
        raise SignaturFehler("Signatur mit unbekanntem Schlüssel")
    try:
        from cryptography.exceptions import InvalidSignature
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
    except ImportError:
        raise SignaturFehler("Signaturprüfung nicht möglich (Paket cryptography fehlt)") from None
    try:
        Ed25519PublicKey.from_public_bytes(base64.b64decode(pub)).verify(raw, nachricht(rid, version, api, sig["sha256"]))
    except (InvalidSignature, ValueError):
        raise SignaturFehler("Signatur passt nicht") from None
    return {"id": rid, "version": version, "api": api}


def sig_datei(py: Path) -> Path:
    return py.with_name(py.stem + ".sig.json")


def pruefe_datei(py: Path, schluessel: dict = None) -> dict:
    try:
        sig = json.loads(sig_datei(py).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        raise SignaturFehler("keine Signatur") from None
    meta = pruefen(py.read_bytes(), sig, schluessel)
    if meta["id"] != py.stem:
        raise SignaturFehler("Signatur gehört zu einem anderen Portal")
    return meta


def signieren(quelle: bytes, rid: str, version: str, api: int, privat_raw: bytes, kid: str) -> dict:
    """Used by the signing tool on the release machine and by the tests (never inside the helper on a person's computer)."""
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    h = sha256(quelle)
    raw = Ed25519PrivateKey.from_private_bytes(privat_raw).sign(nachricht(rid, version, api, h))
    return {"id": rid, "version": version, "api": int(api), "sha256": h, "key": kid,
            "sig": base64.b64encode(raw).decode()}
