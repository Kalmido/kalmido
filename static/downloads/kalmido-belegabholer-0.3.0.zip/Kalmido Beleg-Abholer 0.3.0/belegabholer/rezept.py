"""The recipe interface (API 1) and the recipe loader.

A recipe is ONE Python file per portal (built in: belegabholer/rezepte/<id>.py; delivered from Kalmido:
<settings>/rezepte/<id>.py, only run with a valid signature <id>.sig.json, see signatur.py)
that defines a class `Rezept(Basis)` with:

    ID        portal id, file name and state key, e.g. "amazon"
    NAME      display name, e.g. "Amazon"
    VERSION   "MAJOR.MINOR.PATCH"; the loader takes the highest version of an id whose API it supports
    API       the interface version it was written for (API_VERSION below)
    START_URL the page the visible login browser opens

and the methods

    angemeldet(page) -> bool                        is this profile still logged in? (may navigate)
    belege(page, seit: date, erledigt) -> iterable of Beleg
                                                     the invoices / orders since that date, newest first; an order
                                                     whose invoice is not there yet is a Beleg with url=None (it is
                                                     remembered and checked again in later nights). erledigt(gruppe,
                                                     datum) -> bool: True = this order is done, skip opening it
    laden(page, beleg) -> bytes                      the PDF bytes of a Beleg with url (must start with %PDF)

Errors: raise AnmeldungAbgelaufen when the portal wants a login (or a captcha / second factor), RezeptKaputt when the
page no longer looks as the recipe expects. Both stop this account's run and send a notification.

Recipes must not log or return personal data beyond what the Beleg needs; the runner logs only counts.
A recipe gets `self.pause()` (random, human-like wait) and `self.basis_url` (settings "portale.<id>.basis_url",
used by the tests to point the recipe at local mock pages).
"""
import importlib.util
import random
import re
import time
from dataclasses import dataclass, field
from datetime import date
from pathlib import Path
from typing import Optional

from . import signatur

API_VERSION = 1


class AnmeldungAbgelaufen(Exception):
    """The portal wants a (new) login, a second factor or a captcha."""


class RezeptKaputt(Exception):
    """The page does not look as the recipe expects (the portal changed)."""


@dataclass
class Beleg:
    schluessel: str             # unique per portal account, e.g. "302-1234567-1234567#1"; the state key
    nummer: str                 # for the file name (order / invoice number)
    datum: date                 # order / invoice date
    url: Optional[str] = None   # the PDF; None = no invoice yet (remembered as "ohne Rechnung")
    gruppe: str = ""            # e.g. the order number when an order has several invoices
    art: str = "Rechnung"       # Rechnung | Gutschrift
    extra: dict = field(default_factory=dict)


class Basis:
    ID = ""
    NAME = ""
    VERSION = "0.0.0"
    API = API_VERSION
    START_URL = ""
    BASIS_URL = ""
    QUELLE = ""      # set by the loader: the file it came from
    GELIEFERT = False  # set by the loader: True = delivered from Kalmido (signed), False = built in
    HINWEIS = ""     # one line for the setup's portal list
    MEHRERE_KONTEN = False   # the setup offers "another account?" (each its own browser profile)
    KANAL = ""       # browser: "" = Playwright's Chromium, "chrome" = the installed Google Chrome (falls back)

    def __init__(self, cfg: dict, portal_cfg: dict, pause=None):
        self.cfg = cfg
        self.portal_cfg = portal_cfg or {}
        self.basis_url = (self.portal_cfg.get("basis_url") or self.BASIS_URL).rstrip("/")
        self._pause = pause or cfg.get("pause") or [2.5, 7.0]

    def pause(self, faktor: float = 1.0):
        lo, hi = self._pause
        if hi > 0:
            time.sleep(random.uniform(lo, hi) * faktor)

    def url(self, path: str) -> str:
        return path if re.match(r"https?://|file:", path) else self.basis_url + path

    def start_url(self) -> str:
        return self.url(self.START_URL or "/")

    # --- to implement ---
    def angemeldet(self, page) -> bool:
        raise NotImplementedError

    def belege(self, page, seit: date, erledigt=lambda gruppe, datum: False):
        raise NotImplementedError

    def laden(self, page, beleg: Beleg) -> bytes:
        raise NotImplementedError


def vkey(v: str):
    return tuple(int(x) for x in re.findall(r"\d+", v)[:3]) or (0,)


def _load_file(path: Path, signiert: dict = None):
    # compiled from source every time: no .pyc cache, so a recipe replaced within the same second is never stale
    quelle = path.read_bytes()
    if signiert is not None and signiert.get("sha256") and signatur.sha256(quelle) != signiert["sha256"]:
        raise signatur.SignaturFehler("Rezept zwischen Prüfung und Laden verändert")
    spec = importlib.util.spec_from_file_location(f"belegabholer_rezept_{path.stem}_{abs(hash(str(path)))}", path)
    mod = importlib.util.module_from_spec(spec)
    exec(compile(quelle.decode("utf-8"), str(path), "exec"), mod.__dict__)
    cls = getattr(mod, "Rezept", None)
    if cls is None or not isinstance(cls, type) or not issubclass(cls, Basis):
        raise RezeptKaputt(f"{path.name}: keine Klasse Rezept")
    if signiert is not None and (cls.ID != signiert["id"] or cls.VERSION != signiert["version"]
                                 or cls.API != signiert["api"]):
        raise signatur.SignaturFehler("Rezept passt nicht zu seiner Signatur")
    cls.QUELLE = str(path)
    cls.GELIEFERT = signiert is not None
    return cls


def candidates(extra_dir: Optional[Path] = None):
    """(path, delivered) - built-in recipes first, then the delivered ones."""
    dirs = [(Path(__file__).parent / "rezepte", False)]
    if extra_dir is not None:
        dirs.append((Path(extra_dir), True))
    for d, geliefert in dirs:
        if d.is_dir():
            for p in sorted(d.glob("*.py")):
                if not p.name.startswith("_"):
                    yield p, geliefert


def laden(p: Path, geliefert: bool, schluessel: dict = None):
    """One recipe file -> its class. A delivered file is checked against its signature BEFORE any of it runs."""
    meta = signatur.pruefe_datei(p, schluessel) if geliefert else None
    return _load_file(p, dict(meta, sha256=signatur.sha256(p.read_bytes())) if meta else None)


def available(extra_dir: Optional[Path] = None, abgelehnt: list = None, schluessel: dict = None) -> dict:
    """{id: class} - per id the highest version whose API this tool supports (delivered beats built-in on a tie).
    Delivered files without a valid signature are skipped (and listed in `abgelehnt` as (file name, reason))."""
    best = {}
    for p, geliefert in candidates(extra_dir):
        try:
            cls = laden(p, geliefert, schluessel)
        except signatur.SignaturFehler as e:
            if abgelehnt is not None:
                abgelehnt.append((p.name, str(e)))
            continue
        except Exception:  # a broken delivered file must not break the others
            continue
        if cls.API != API_VERSION or not cls.ID:
            continue
        cur = best.get(cls.ID)
        if cur is None or vkey(cls.VERSION) >= vkey(cur.VERSION):
            best[cls.ID] = cls
    return best
