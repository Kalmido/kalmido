"""belegabholer einrichten | login | run | status | nachtlauf | rezepte | verbinden ... - the commands (German output,
no personal data in logs). Runs on the Mac and on Windows (plattform.py)."""
import argparse
import json
import logging
import logging.handlers
import os
import random
import re
import shutil
import subprocess
import sys
import time
from pathlib import Path

from . import __version__, abholen, ablage, browser, einstellungen, meldung, plattform, rezept, verteilung

log = logging.getLogger("belegabholer")
LAUNCH_LABEL = plattform.LAUNCH_LABEL
BEFEHL = "belegabholer"


def setup_logging(verbose: bool):
    home = einstellungen.home()
    home.mkdir(parents=True, exist_ok=True)
    os.chmod(home, 0o700)
    log.setLevel(logging.INFO)
    fh = logging.handlers.RotatingFileHandler(einstellungen.log_file(), maxBytes=512_000, backupCount=3, encoding="utf-8")
    fh.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
    log.addHandler(fh)
    if verbose:
        sh = logging.StreamHandler()
        sh.setFormatter(logging.Formatter("%(message)s"))
        log.addHandler(sh)


def rezepte(abgelehnt=None):
    return rezept.available(einstellungen.recipes_dir(), abgelehnt)


def konten(cfg, portal):
    return list(((cfg.get("portale") or {}).get(portal) or {}).get("konten") or ["standard"])


def rezept_oder_ende(portal):
    alle = rezepte()
    if portal not in alle:
        sys.exit(f"Unbekanntes Portal '{portal}'. Vorhanden: {', '.join(sorted(alle)) or 'keine'}")
    return alle[portal]


def cmd_login(a, cfg):
    cls = rezept_oder_ende(a.portal)
    konto = a.konto or "standard"
    if konto not in konten(cfg, cls.ID):  # a new account (e.g. a second Google account) is added to the settings
        cfg.setdefault("portale", {}).setdefault(cls.ID, {}).setdefault("konten", konten(cfg, cls.ID)).append(konto)
        einstellungen.save(cfg)
    rez = cls(cfg, (cfg.get("portale") or {}).get(cls.ID) or {})
    print(f"Öffne {cls.NAME} (Konto '{konto}') im sichtbaren Browser.")
    print("Bitte dort selbst anmelden (auch zweiter Faktor), 'Angemeldet bleiben' anhaken, dann das Browserfenster schließen.")
    try:
        with browser.profil(einstellungen.profile_dir(cls.ID, konto), sichtbar=True, kanal=browser.kanal(cls, cfg)) as ctx:
            page = browser.erste_seite(ctx)
            page.goto(rez.start_url(), wait_until="domcontentloaded")
            closed = []
            ctx.on("close", lambda *_: closed.append(1))
            while not closed and ctx.pages:
                time.sleep(1)
    except browser.ProfilBelegt:
        sys.exit("Das Browserprofil ist schon offen (läuft gerade ein Abruf oder ein zweites Login-Fenster?).")
    print("Prüfe die Anmeldung unsichtbar ...")
    ok = pruefe_anmeldung(cls, konto, cfg)
    log.info("login %s/%s: %s", cls.ID, konto, "angemeldet" if ok else "nicht angemeldet")
    print("Angemeldet. Der Nachtlauf holt ab jetzt die Rechnungen." if ok else
          f"Noch nicht angemeldet. Bitte erneut: {BEFEHL} login {cls.ID}" + (f" --konto {konto}" if konto != "standard" else ""))
    return 0 if ok else 1


def pruefe_anmeldung(cls, konto, cfg) -> bool:
    rez = cls(cfg, (cfg.get("portale") or {}).get(cls.ID) or {}, pause=[0, 0])
    try:
        with browser.profil(einstellungen.profile_dir(cls.ID, konto), kanal=browser.kanal(cls, cfg)) as ctx:
            return rez.angemeldet(browser.erste_seite(ctx))
    except rezept.AnmeldungAbgelaufen:
        return False


def login_befehl(portal, konto):
    return f"{BEFEHL} login {portal}" + (f" --konto {konto}" if konto != "standard" else "")


def cmd_run(a, cfg):
    try:
        with plattform.sperre(einstellungen.home() / ".lauf.lock"):
            return _run(a, cfg)
    except plattform.Belegt:
        print("Es läuft schon ein Abruf.")
        return 0


def rezepte_holen(abl) -> None:
    """Newer signed recipes from Kalmido (central distribution); quiet when there are none or Kalmido has no route."""
    erg = verteilung.holen(abl, einstellungen.recipes_dir())
    for rid, version in erg.neu:
        print(f"Rezept {rid} {version} aus Kalmido übernommen")
    for rid, grund in erg.abgelehnt:
        print(f"Rezept {rid} aus Kalmido abgelehnt: {grund}")


def _run(a, cfg):
    if a.nacht:
        jitter = int((cfg.get("nachtlauf") or {}).get("jitter_min", 25))
        time.sleep(random.uniform(0, jitter * 60))
    portale = [a.portal] if a.portal else list((cfg.get("portale") or {}).keys())
    folder, herkunft = einstellungen.output_dir(cfg)
    try:
        abl = ablage.make(cfg)
    except ablage.AblageFehler as e:
        print(str(e))
        meldung.senden(cfg, "Beleg-Abholer: Kalmido neu verbinden", str(e))
        return 4
    if abl.name == "ordner":
        print(f"Ablage: {folder} ({herkunft})")
    else:
        print(f"Ablage: Kalmido ({abl.v['url']})")
        try:
            gesendet, warten = abl.nachreichen()
            if gesendet or warten:
                print(f"Warteschlange: {gesendet} nachgereicht" + (f", {warten} warten weiter" if warten else ""))
        except ablage.AblageFehler as e:
            print(str(e))
            meldung.senden(cfg, "Beleg-Abholer: Kalmido neu verbinden", str(e))
            return 4
        rezepte_holen(abl)
    alle = rezepte()
    rc = 0
    for p in portale:
        if p not in alle:
            print(f"{p}: kein Rezept vorhanden, übersprungen")
            continue
        for k in ([a.konto] if a.konto else konten(cfg, p)):
            erg = abholen.lauf(alle[p], k, cfg, ablage=abl, sichtbar=a.sichtbar)
            # Kalmido got the state report: it tells the person itself (News + push), so no second push via ntfy
            ohne = ("ntfy",) if getattr(abl, "status_ok", False) else ()
            name = alle[p].NAME + ("" if k == "standard" else f" ({k})")
            zeile = f"{name}: {erg.neu} neue Rechnung(en)"
            if erg.doppelt:
                zeile += f", {erg.doppelt} doppelt"
            if erg.ohne_rechnung:
                zeile += f", {erg.ohne_rechnung} Bestellung(en) noch ohne Rechnung"
            if not erg.vollstaendig:
                zeile += ", Rest folgt im nächsten Lauf"
            if getattr(abl, "in_warteschlange", 0):
                zeile += f" (Kalmido nicht erreichbar: {abl.in_warteschlange} in der Warteschlange)"
            if erg.ergebnis == "anmeldung":
                rc = 2
                zeile = f"{name}: Anmeldung abgelaufen. Neu einloggen mit: {login_befehl(p, k)}"
                meldung.senden(cfg, f"Beleg-Abholer: {name} neu einloggen",
                               f"Die Anmeldung bei {name} ist abgelaufen. Im Terminal: {login_befehl(p, k)}", ohne)
            elif erg.ergebnis in ("kaputt", "fehler"):
                rc = 3
                zeile = f"{name}: Rezept {erg.rezept} passt nicht mehr ({erg.fehler})"
                meldung.senden(cfg, f"Beleg-Abholer: Rezept {name} kaputt",
                               f"Das Rezept {erg.rezept} findet die Rechnungen nicht mehr ({erg.fehler}). "
                               f"Prüfen mit: {BEFEHL} run {p} --sichtbar", ohne)
            elif erg.ergebnis == "belegt":
                zeile = f"{name}: übersprungen, das Browserprofil ist gerade offen"
            elif erg.ergebnis == "aus":
                zeile = f"{name}: in Kalmido ausgeschaltet, übersprungen"
            elif erg.ergebnis == "verbindung":
                print(f"{name}: {erg.fehler}")
                meldung.senden(cfg, "Beleg-Abholer: Kalmido neu verbinden", erg.fehler)
                return 4
            print(zeile)
    return rc


def cmd_status(a, cfg):
    folder, herkunft = einstellungen.output_dir(cfg)
    print(f"Kalmido Beleg-Abholer {__version__}")
    print(f"Einstellungen: {einstellungen.home()}")
    if cfg.get("ablage") == "kalmido":
        v = ablage.verbindung_laden()
        print(f"Ablage: Kalmido -> {v['url'] if v else 'NICHT VERBUNDEN (belegabholer verbinden <Einrichtungscode>)'}")
        q = einstellungen.queue_dir()
        n = len(list(q.glob("*.pdf"))) if q.exists() else 0
        if n:
            print(f"Warteschlange: {n} Beleg(e) warten auf Kalmido (gehen beim nächsten Lauf raus)")
    else:
        print(f"Ablage: Ordner -> {folder} ({herkunft})")
    st = {}
    if einstellungen.status_file().exists():
        st = json.loads(einstellungen.status_file().read_text(encoding="utf-8"))
    abgelehnt = []
    alle = rezepte(abgelehnt)
    for p in (cfg.get("portale") or {}):
        for k in konten(cfg, p):
            cls = alle.get(p)
            z = abholen.zustand_fuer(p, k)
            s = st.get(f"{p}/{k}") or {}
            prof = einstellungen.profile_dir(p, k).exists()
            print(f"\n{(cls.NAME if cls else p)} / Konto {k}" + (f"  (Rezept {cls.VERSION})" if cls else "  (kein Rezept)"))
            print(f"  Browserprofil: {'vorhanden' if prof else 'fehlt - ' + login_befehl(p, k)}")
            print(f"  Geholt: {len(z.data['geholt'])}, ohne Rechnung (wird nachts erneut geprüft): {len(z.data['ohne_rechnung'])}")
            if s:
                print(f"  Letzter Lauf: {s.get('letzter_lauf', '-').replace('T', ' ')} - {s.get('ergebnis')}, neu {s.get('neu', 0)}"
                      + (f", Fehler: {s['fehler']}" if s.get("fehler") else ""))
            else:
                print("  Letzter Lauf: noch keiner")
    for name, grund in abgelehnt:
        print(f"\nGeliefertes Rezept {name} wird nicht benutzt: {grund}")
    an, um = plattform.nachtlauf_stand(cfg)
    if an:
        print(f"\nNachtlauf: an, täglich {um} (+ zufällig bis {(cfg.get('nachtlauf') or {}).get('jitter_min', 25)} min)")
    else:
        print(f"\nNachtlauf: aus ({BEFEHL} nachtlauf an)")
    print("ntfy: " + ("eingerichtet" if (einstellungen.home() / "ntfy.env").exists() else "nicht eingerichtet (nur Mac-Mitteilung)"))
    return 0


def befehl_pfad() -> str:
    """The command the night run starts (the shim the installer wrote)."""
    found = shutil.which(BEFEHL)
    if found:
        return found
    if plattform.system() == "windows":   # install.ps1: program in %LOCALAPPDATA%, settings in %APPDATA%
        return str(Path(os.environ.get("LOCALAPPDATA") or Path.home() / "AppData" / "Local")
                   / einstellungen.APP_NAME / "bin" / f"{BEFEHL}.cmd")
    return str(Path.home() / ".local" / "bin" / BEFEHL)


def cmd_nachtlauf(a, cfg):
    if a.an_aus == "aus":
        plattform.nachtlauf_aus()
        print("Nachtlauf aus.")
        return 0
    nl = cfg.setdefault("nachtlauf", {})
    if nl.get("minute") is None:
        nl["minute"] = random.randint(0, 59)
        einstellungen.save(cfg)
    ok, fehler = plattform.nachtlauf_an(befehl_pfad(), int(nl.get("stunde", 3)), int(nl["minute"]), einstellungen.home())
    if not ok:
        sys.exit(fehler)
    nachholen = ("Ein verpasster Lauf (Mac im Ruhezustand) folgt beim Aufwachen." if plattform.system() == "mac" else
                 "War der Rechner aus, holt der nächste Lauf alles nach (40 Tage zurück).")
    print(f"Nachtlauf an: täglich {int(nl.get('stunde', 3)):02d}:{int(nl['minute']):02d} plus zufällig bis "
          f"{nl.get('jitter_min', 25)} Minuten. {nachholen}")
    return 0


def cmd_rezepte(a, cfg):
    if a.holen:
        try:
            abl = ablage.KalmidoAblage(cfg)
        except ablage.AblageFehler as e:
            sys.exit(str(e))
        erg = verteilung.holen(abl, einstellungen.recipes_dir())
        if not erg.erreichbar:
            print("Kalmido nicht erreichbar, Rezepte unverändert.")
        for rid, version in erg.neu:
            print(f"Neu aus Kalmido: {rid} {version}")
        for rid, grund in erg.abgelehnt:
            print(f"Abgelehnt: {rid} ({grund})")
        if erg.erreichbar and not erg.neu and not erg.abgelehnt:
            print("Keine neueren Rezepte in Kalmido.")
    abgelehnt = []
    for pid, cls in sorted(rezepte(abgelehnt).items()):
        src = "aus Kalmido, signiert" if cls.GELIEFERT else "eingebaut"
        print(f"{pid:10} {cls.NAME:12} Version {cls.VERSION} (API {cls.API}, {src})")
    for name, grund in abgelehnt:
        print(f"{name}: nicht benutzt ({grund})")
    return 0


def cmd_verbinden(a, cfg):
    code = a.code
    if not code:
        print("Einrichtungscode aus Kalmido (Einstellungen > Integrationen > Beleg-Abholer) einfügen, dann Enter:")
        code = sys.stdin.readline().strip()
    return verbinden(code, cfg)


def verbinden(code: str, cfg: dict) -> int:
    """Connects with a setup code; sys.exit with a German message when it does not work."""
    try:
        v = ablage.setup_code_lesen(code)
    except ValueError as e:
        sys.exit(str(e))
    abl = ablage.KalmidoAblage(cfg, v)
    try:
        info = abl.pruefen()
    except ablage.AblageFehler as e:
        sys.exit(str(e))
    except OSError as e:
        sys.exit(f"Kalmido unter {v['url']} nicht erreichbar ({type(e).__name__}). Internet / Adresse prüfen.")
    ablage.verbindung_speichern(v)
    cfg["ablage"] = "kalmido"
    einstellungen.save(cfg)
    melde_portale(cfg, abl)
    ziel = info.get("target") or "deine Dokumente"
    print(f"Verbunden mit Kalmido ({v['url']}) als \"{info.get('name') or v.get('name') or 'Beleg-Abholer'}\".")
    print(f"Neue Rechnungen gehen ab jetzt direkt nach Kalmido ({ziel}), nicht mehr in den Ordner.")
    log.info("verbunden mit Kalmido")
    return 0


def melde_portale(cfg, abl=None):
    """Announce the portals of this helper so they show up in Kalmido at once (new = switched on)."""
    if cfg.get("ablage") != "kalmido":
        return
    try:
        abl = abl or ablage.KalmidoAblage(cfg)
        alle = rezepte()
        abl._melden([{"key": ablage.portal_key(p, k), "name": ((alle[p].NAME if p in alle else p)
                      + ("" if k == "standard" else f" ({k})"))[:80]}
                     for p in (cfg.get("portale") or {}) for k in konten(cfg, p)])
    except (OSError, ablage.AblageFehler):
        pass


def konto_name(text: str) -> str:
    """A short account name for the profile folder and Kalmido's key: a-z 0-9 _ -, up to 20 (empty = standard)."""
    n = re.sub(r"[^a-z0-9_-]+", "-", (text or "").strip().lower().replace("ä", "ae").replace("ö", "oe")
               .replace("ü", "ue").replace("ß", "ss")).strip("-")[:20]
    return n or "standard"


def ja(antwort: str, vorgabe: bool) -> bool:
    a = (antwort or "").strip().lower()
    return vorgabe if not a else a[0] in "jy"


def cmd_einrichten(a, cfg, frage=input):
    """The guided setup for people without a terminal habit: setup code, choose portals, log in (several accounts
    per portal, e.g. two Google accounts), night run on, first run. Every step can be repeated later on its own."""
    print(f"Kalmido Beleg-Abholer {__version__} - Einrichtung\n")
    # 1. Kalmido
    if cfg.get("ablage") == "kalmido" and ablage.verbindung_laden():
        print("1. Kalmido: schon verbunden.")
    else:
        print("1. Mit Kalmido verbinden: in Kalmido unter Einstellungen > Integrationen > Beleg-Abholer einen Abholer")
        print("   anlegen und den Einrichtungscode kopieren. Leer lassen = ohne Kalmido, die PDFs kommen in einen Ordner.")
        while True:
            code = frage("   Einrichtungscode: ").strip()
            if not code:
                folder, herkunft = einstellungen.output_dir(cfg)
                print(f"   Ohne Kalmido. Ablage: {folder} ({herkunft})")
                break
            try:
                verbinden(code, cfg)
                break
            except SystemExit as e:
                print(f"   {e}")
    # 2. portals
    alle = rezepte()
    ids = sorted(alle)
    jetzt = [p for p in (cfg.get("portale") or {}) if p in alle]
    print("\n2. Welche Portale? Nummern mit Komma, z. B. 1,2 (Enter = " + (", ".join(alle[p].NAME for p in jetzt) or "keins") + ")")
    for i, pid in enumerate(ids, 1):
        print(f"   {i}. {alle[pid].NAME}" + (f" - {alle[pid].HINWEIS}" if getattr(alle[pid], "HINWEIS", "") else ""))
    while True:
        wahl = frage("   Portale: ").strip()
        if not wahl:
            gewaehlt = jetzt
            break
        try:
            nr = [int(x) for x in re.split(r"[,\s]+", wahl) if x]
            if all(1 <= n <= len(ids) for n in nr):
                gewaehlt = list(dict.fromkeys(ids[n - 1] for n in nr))
                break
        except ValueError:
            pass
        print(f"   Bitte Nummern zwischen 1 und {len(ids)}.")
    if not gewaehlt:
        print("   Kein Portal gewählt. Später: belegabholer einrichten")
        return 1
    alt = cfg.get("portale") or {}
    cfg["portale"] = {p: dict(alt.get(p) or {}, konten=list((alt.get(p) or {}).get("konten") or ["standard"]))
                      for p in gewaehlt}
    einstellungen.save(cfg)
    # 3. logins
    print("\n3. Anmelden: je Konto öffnet sich ein Browserfenster. Dort selbst anmelden (auch Code per SMS / App),")
    print("   'Angemeldet bleiben' anhaken, dann das Fenster schließen. Das Passwort bleibt im Browser auf diesem Rechner.")
    fehlt = []
    for pid in gewaehlt:
        cls = alle[pid]
        for k in list(cfg["portale"][pid]["konten"]):
            if einstellungen.profile_dir(pid, k).exists() and not ja(frage(
                    f"   {cls.NAME} ({k}) hat schon eine Anmeldung. Neu anmelden? (j/N) "), False):
                continue
            if cmd_login(argparse.Namespace(portal=pid, konto=k), cfg) != 0:
                fehlt.append(login_befehl(pid, k))
        while getattr(cls, "MEHRERE_KONTEN", False) and ja(frage(f"   Noch ein {cls.NAME}-Konto? (j/N) "), False):
            k = konto_name(frage("   Kurzer Name für dieses Konto, z. B. buero: "))
            if k in cfg["portale"][pid]["konten"]:
                print(f"   '{k}' gibt es schon.")
                continue
            cfg["portale"][pid]["konten"].append(k)
            einstellungen.save(cfg)
            if cmd_login(argparse.Namespace(portal=pid, konto=k), cfg) != 0:
                fehlt.append(login_befehl(pid, k))
    melde_portale(cfg)
    # 4. night run
    print("\n4. Nachtlauf")
    try:
        cmd_nachtlauf(argparse.Namespace(an_aus="an"), cfg)
    except SystemExit as e:
        print(f"   Nachtlauf noch aus ({e}). Später: belegabholer nachtlauf an")
    # 5. first run
    if fehlt:
        print("\nNoch nicht angemeldet - bitte nachholen:")
        for b in fehlt:
            print(f"   {b}")
    if ja(frage("\n5. Jetzt den ersten Abruf starten? Das kann ein paar Minuten dauern. (J/n) "), True):
        return cmd_run(argparse.Namespace(portal=None, konto=None, sichtbar=False, nacht=False), einstellungen.load())
    print("Fertig. Der Nachtlauf holt die Rechnungen ab jetzt von selbst.")
    return 0


def cmd_trennen(a, cfg):
    einstellungen.kalmido_file().unlink(missing_ok=True)
    cfg["ablage"] = "ordner"
    einstellungen.save(cfg)
    folder, herkunft = einstellungen.output_dir(cfg)
    print(f"Von Kalmido getrennt (Schlüssel hier gelöscht; in Kalmido den Abholer bitte auch trennen). "
          f"Ablage wieder: {folder} ({herkunft})")
    q = einstellungen.queue_dir()
    if q.exists() and list(q.glob("*.pdf")):
        print(f"Hinweis: in {q} warten noch Belege, die Kalmido nicht erreicht haben.")
    return 0


def cmd_ordner(a, cfg):
    if a.pfad:
        cfg["ausgabe"] = None if a.pfad == "auto" else str(Path(a.pfad).expanduser())
        einstellungen.save(cfg)
        if cfg.get("ablage") == "kalmido":
            print("Hinweis: die Ablage ist Kalmido (direkter Upload); der Ordner gilt erst nach 'belegabholer trennen'.")
    folder, herkunft = einstellungen.output_dir(cfg)
    print(f"Ablage: {folder} ({herkunft})")
    return 0


def main(argv=None):
    ap = argparse.ArgumentParser(prog=BEFEHL, description="Kalmido Beleg-Abholer: Rechnungen aus Portalen holen (lokal).")
    ap.add_argument("-v", "--verbose", action="store_true", help="Protokoll auch im Terminal zeigen")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("einrichten", help="geführte Einrichtung: Kalmido verbinden, Portale wählen, anmelden, Nachtlauf")
    p = sub.add_parser("login", help="sichtbarer Browser: einmal selbst anmelden (auch zweiter Faktor)")
    p.add_argument("portal")
    p.add_argument("--konto", help="Name des Kontos bei mehreren Konten je Portal (Standard: standard)")
    p = sub.add_parser("run", help="neue Rechnungen holen (unsichtbar)")
    p.add_argument("portal", nargs="?")
    p.add_argument("--konto")
    p.add_argument("--sichtbar", action="store_true", help="Browser dabei zeigen (Fehlersuche)")
    p.add_argument("--nacht", action="store_true", help=argparse.SUPPRESS)
    sub.add_parser("status", help="Stand je Portal und Konto")
    p = sub.add_parser("nachtlauf", help="Nachtlauf an- oder ausschalten (Mac: launchd, Windows: Aufgabenplanung)")
    p.add_argument("an_aus", choices=["an", "aus"])
    p = sub.add_parser("rezepte", help="vorhandene Rezepte und Versionen")
    p.add_argument("--holen", action="store_true", help="jetzt neuere, signierte Rezepte aus Kalmido holen")
    p = sub.add_parser("ordner", help="Ablage-Ordner zeigen oder setzen ('auto' = Ordner-Wächter)")
    p.add_argument("pfad", nargs="?")
    p = sub.add_parser("verbinden", help="direkt mit Kalmido verbinden (Einrichtungscode aus den Einstellungen)")
    p.add_argument("code", nargs="?", help="kalmido-fetch:1:... (ohne: wird abgefragt, landet nicht in der Shell-Historie)")
    sub.add_parser("trennen", help="Kalmido-Verbindung lösen, wieder in den Ordner ablegen")
    a = ap.parse_args(argv)
    setup_logging(a.verbose)
    cfg = einstellungen.load()
    fn = {"einrichten": cmd_einrichten, "login": cmd_login, "run": cmd_run, "status": cmd_status, "nachtlauf": cmd_nachtlauf,
          "rezepte": cmd_rezepte, "ordner": cmd_ordner, "verbinden": cmd_verbinden, "trennen": cmd_trennen}[a.cmd]
    return fn(a, cfg)
