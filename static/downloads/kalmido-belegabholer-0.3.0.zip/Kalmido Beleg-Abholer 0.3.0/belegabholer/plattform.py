"""What differs between Mac and Windows (#3454): settings folder (einstellungen.py), the run lock, the night run
(launchd on the Mac, the Task Scheduler on Windows) and the system notification (banner / toast).

The command builders are plain functions, so the tests check them on any system; only the *_ausfuehren parts call
launchctl / schtasks / powershell.
"""
import contextlib
import os
import plistlib
import subprocess
import sys
from pathlib import Path

LAUNCH_LABEL = "com.kalmido.belegabholer"
TASK_NAME = "Kalmido Beleg-Abholer"


def system() -> str:
    if sys.platform == "darwin":
        return "mac"
    if sys.platform.startswith("win"):
        return "windows"
    return "linux"


# ---------- run lock ----------

class Belegt(Exception):
    """Another run holds the lock."""


@contextlib.contextmanager
def sperre(path: Path):
    """An exclusive, non-blocking lock on a file for the whole run (fcntl on Mac / Linux, msvcrt on Windows)."""
    path.parent.mkdir(parents=True, exist_ok=True)
    f = open(path, "a+")
    try:
        if os.name == "nt":
            import msvcrt
            try:
                f.seek(0)
                msvcrt.locking(f.fileno(), msvcrt.LK_NBLCK, 1)
            except OSError:
                raise Belegt() from None
        else:
            import fcntl
            try:
                fcntl.flock(f, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError:
                raise Belegt() from None
        yield
    finally:
        f.close()


# ---------- night run ----------

def launchd_plist(exe: str, stunde: int, minute: int, home: Path) -> bytes:
    return plistlib.dumps({
        "Label": LAUNCH_LABEL,
        "ProgramArguments": [exe, "run", "--nacht"],
        "StartCalendarInterval": {"Hour": int(stunde), "Minute": int(minute)},
        "StandardOutPath": str(home / "nachtlauf.out"),
        "StandardErrorPath": str(home / "nachtlauf.out"),
        "ProcessType": "Background",
        "LowPriorityIO": True,
        "Nice": 10,
    })


def plist_pfad() -> Path:
    return Path.home() / "Library" / "LaunchAgents" / f"{LAUNCH_LABEL}.plist"


def schtasks_an(exe: str, stunde: int, minute: int) -> list:
    """Task Scheduler: daily at HH:MM in the user's own session (no admin, no stored password); /F replaces an old one.
    A missed run (computer off) is not caught up by schtasks itself; the next night fetches the rest (40 days back)."""
    return ["schtasks", "/Create", "/F", "/SC", "DAILY", "/TN", TASK_NAME, "/ST", f"{int(stunde):02d}:{int(minute):02d}",
            "/TR", f'"{exe}" run --nacht']


def schtasks_aus() -> list:
    return ["schtasks", "/Delete", "/F", "/TN", TASK_NAME]


def schtasks_abfrage() -> list:
    return ["schtasks", "/Query", "/TN", TASK_NAME]


def _run(cmd):
    return subprocess.run(cmd, capture_output=True, text=True)


def nachtlauf_an(exe: str, stunde: int, minute: int, home: Path):
    """-> (ok, error text)."""
    s = system()
    if s == "mac":
        uid = os.getuid()
        plist = plist_pfad()
        _run(["launchctl", "bootout", f"gui/{uid}/{LAUNCH_LABEL}"])
        plist.parent.mkdir(parents=True, exist_ok=True)
        plist.write_bytes(launchd_plist(exe, stunde, minute, home))
        r = _run(["launchctl", "bootstrap", f"gui/{uid}", str(plist)])
        if r.returncode != 0:
            plist.unlink(missing_ok=True)   # not loaded = not on; status must not claim a night run that never comes
            return False, f"launchctl: {r.stderr.strip() or r.returncode}"
        return True, ""
    if s == "windows":
        r = _run(schtasks_an(exe, stunde, minute))
        return (r.returncode == 0), (f"schtasks: {(r.stderr or r.stdout).strip() or r.returncode}" if r.returncode else "")
    return False, "Der Nachtlauf geht nur auf dem Mac (launchd) und unter Windows (Aufgabenplanung)."


def nachtlauf_aus():
    s = system()
    if s == "mac":
        _run(["launchctl", "bootout", f"gui/{os.getuid()}/{LAUNCH_LABEL}"])
        plist_pfad().unlink(missing_ok=True)
    elif s == "windows":
        _run(schtasks_aus())


def nachtlauf_stand(cfg: dict):
    """-> (on, "HH:MM") or (False, "")."""
    s = system()
    if s == "mac":
        p = plist_pfad()
        if not p.exists():
            return False, ""
        d = plistlib.loads(p.read_bytes()).get("StartCalendarInterval") or {}
        return True, f"{d.get('Hour', 0):02d}:{d.get('Minute', 0):02d}"
    if s == "windows":
        try:
            r = _run(schtasks_abfrage())
        except OSError:
            return False, ""
        if r.returncode != 0:
            return False, ""
        nl = cfg.get("nachtlauf") or {}
        return True, f"{int(nl.get('stunde', 3)):02d}:{int(nl.get('minute') or 0):02d}"
    return False, ""


# ---------- system notification ----------

def _ps_quote(s: str) -> str:
    return "'" + s.replace("'", "''") + "'"


def _xml(s: str) -> str:
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")


def toast_skript(titel: str, text: str) -> str:
    """PowerShell for a Windows toast without extra modules (the PowerShell app id shows it)."""
    xml = (f"<toast><visual><binding template=\"ToastGeneric\"><text>{_xml(titel)}</text><text>{_xml(text)}</text>"
           f"</binding></visual></toast>")
    return ("[Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType=WindowsRuntime] > $null;"
            "[Windows.Data.Xml.Dom.XmlDocument, Windows.Data.Xml.Dom.XmlDocument, ContentType=WindowsRuntime] > $null;"
            "$x = New-Object Windows.Data.Xml.Dom.XmlDocument; $x.LoadXml(" + _ps_quote(xml) + ");"
            "$app = '{1AC14E77-02E7-4E5D-B744-2EB1AE5198B7}\\WindowsPowerShell\\v1.0\\powershell.exe';"
            "[Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier($app).Show("
            "[Windows.UI.Notifications.ToastNotification]::new($x))")


def osascript_skript(titel: str, text: str) -> str:
    def q(s):
        return '"' + s.replace("\\", "\\\\").replace('"', '\\"') + '"'
    return f"display notification {q(text)} with title {q(titel)}"


def mitteilung(titel: str, text: str) -> bool:
    s = system()
    try:
        if s == "mac":
            subprocess.run(["osascript", "-e", osascript_skript(titel, text)], timeout=10, capture_output=True)
            return True
        if s == "windows":
            flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
            subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", toast_skript(titel, text)],
                           timeout=20, capture_output=True, creationflags=flags)
            return True
    except Exception:  # never fail the run because of the notification
        return False
    return False
