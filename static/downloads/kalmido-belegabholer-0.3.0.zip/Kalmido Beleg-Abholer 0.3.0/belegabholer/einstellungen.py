"""Paths and settings (einstellungen.json in the settings folder).

The settings folder: macOS ~/Library/Application Support/Kalmido Beleg-Abholer, Windows %APPDATA%\\Kalmido Beleg-Abholer,
elsewhere ~/.config/kalmido-belegabholer;
env BELEGABHOLER_HOME overrides it (tests). Nothing in here is secret: no passwords, no tokens. The ntfy token, if
any, lives in its own file ntfy.env (mode 600) next to it, the Kalmido key in kalmido.json (mode 600).
"""
import json
import os
import sys
from pathlib import Path

APP_NAME = "Kalmido Beleg-Abholer"
FOLDERWATCH_NAME = "Kalmido Folder Watcher"

DEFAULTS = {
    # None = the folder the Kalmido folder watcher watches (its config.json), else ~/Belege/Eingang
    "ausgabe": None,
    # first run of an account: invoices of the current year and the N-1 years before (2 = current + last year)
    "erster_lauf_jahre": 2,
    # orders without an invoice are checked again every night for this many days after first seen, then given up
    "ohne_rechnung_tage": 60,
    # pause between page steps in seconds (min, max), random in between: slow, human-like
    "pause": [2.5, 7.0],
    # night run: the hour; the minute is drawn at install time, plus a random 0..jitter minutes wait at the start
    "nachtlauf": {"stunde": 3, "minute": None, "jitter_min": 25},
    # portals and their accounts (one browser profile per account)
    "portale": {"amazon": {"konten": ["standard"]}},
    # the delivery layer: "ordner" (folder the folder watcher uploads) or "kalmido" (direct upload, `belegabholer verbinden`)
    "ablage": "ordner",
    # notification on expired login / broken recipe: "ntfy" (ntfy.env next to this file) and/or "system" (Mac banner /
    # Windows toast; the older value "mac" means the same)
    "meldung": ["ntfy", "system"],
}


def _appdata() -> Path:
    return Path(os.environ.get("APPDATA") or (Path.home() / "AppData" / "Roaming"))


def home() -> Path:
    env = os.environ.get("BELEGABHOLER_HOME")
    if env:
        return Path(env)
    if sys.platform == "darwin":
        return Path.home() / "Library" / "Application Support" / APP_NAME
    if sys.platform.startswith("win"):
        return _appdata() / APP_NAME
    return Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config")) / "kalmido-belegabholer"


def folderwatch_config() -> Path:
    env = os.environ.get("BELEGABHOLER_FOLDERWATCH_CONFIG")
    if env:
        return Path(env)
    if sys.platform == "darwin":
        return Path.home() / "Library" / "Application Support" / FOLDERWATCH_NAME / "config.json"
    if sys.platform.startswith("win"):
        return _appdata() / FOLDERWATCH_NAME / "config.json"
    return Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config")) / FOLDERWATCH_NAME / "config.json"


def profiles_dir() -> Path:
    return home() / "profile"


def profile_dir(portal: str, konto: str) -> Path:
    return profiles_dir() / f"{portal}-{konto}"


def state_dir() -> Path:
    return home() / "zustand"


def recipes_dir() -> Path:
    """Recipes delivered later (central distribution) land here and win over the built-in ones by version."""
    return home() / "rezepte"


def kalmido_file() -> Path:
    """The connection to Kalmido from the setup code: url + the helper's own key (mode 600, never logged)."""
    return home() / "kalmido.json"


def queue_dir() -> Path:
    """PDFs fetched while Kalmido was unreachable; sent at the start of the next run."""
    return home() / "warteschlange"


def log_file() -> Path:
    return home() / "belegabholer.log"


def status_file() -> Path:
    return home() / "status.json"


def _merge(base, extra):
    out = dict(base)
    for k, v in (extra or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _merge(out[k], v)
        else:
            out[k] = v
    return out


def load() -> dict:
    p = home() / "einstellungen.json"
    data = {}
    if p.exists():
        data = json.loads(p.read_text(encoding="utf-8"))
    out = _merge(DEFAULTS, data)
    if isinstance(data.get("portale"), dict):   # the chosen portals replace the default (Amazon), never add to it
        out["portale"] = data["portale"]
    return out


def save(cfg: dict) -> None:
    p = home() / "einstellungen.json"
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(cfg, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.replace(tmp, p)


def folderwatch_folder():
    """The folder the folder watcher uploads from, or None. Reads ONLY the folder fields of its config.json
    (the file also holds the upload key, which is never read into logs or output)."""
    p = folderwatch_config()
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    folders = [i.get("folder") for i in data.get("inboxes") or [] if isinstance(i, dict) and i.get("folder")]
    if not folders:
        return None
    # several inboxes: prefer one named like receipts ("Beleg", "Rechnung", "Eingang"), else the first
    for i in data.get("inboxes") or []:
        name = (i.get("name") or "").lower()
        if i.get("folder") and any(w in name for w in ("beleg", "rechnung", "receipt", "invoice")):
            return Path(i["folder"]).expanduser()
    return Path(folders[0]).expanduser()


def output_dir(cfg: dict):
    """(folder, origin): the configured folder, else the folder watcher's, else ~/Belege/Eingang."""
    if cfg.get("ausgabe"):
        return Path(cfg["ausgabe"]).expanduser(), "eingestellt"
    fw = folderwatch_folder()
    if fw:
        return fw, "Ordner-Wächter"
    return Path.home() / "Belege" / "Eingang", "Standard"
