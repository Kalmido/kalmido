"""Central recipes (#3454): at the start of a run, a helper connected to Kalmido asks for newer recipe versions.

Route (receipt fetcher key, docs/API.md "Receipt fetcher"):

    GET /api/v1/fetcher/recipes?api=1
    -> {"recipes": [{"id", "version", "api", "sha256", "key", "sig", "source"}]}

`source` is the recipe file (UTF-8 text); the other fields are its signature document (signatur.py). Kalmido only
hands out what was signed on the release machine; the helper checks the signature itself anyway (a server or a man in the middle
cannot slip it code). A recipe is stored only if it is newer than the one this helper runs now and its signature
checks out; then <settings>/rezepte/<id>.py + <id>.sig.json are replaced atomically. A Kalmido without the route
(404) or an unreachable one changes nothing: the run goes on with the recipes it has.
"""
import json
import logging
import os
import re
from pathlib import Path

from . import rezept, signatur

log = logging.getLogger("belegabholer")
ID_RE = re.compile(r"[a-z0-9_]{1,40}")


class Ergebnis:
    def __init__(self):
        self.neu = []          # [(id, version)]
        self.abgelehnt = []    # [(id, reason)]
        self.erreichbar = True


def holen(abl, ziel: Path, schluessel: dict = None) -> Ergebnis:
    """abl: a KalmidoAblage (its key and HTTP). Never raises for network trouble; returns what changed."""
    erg = Ergebnis()
    try:
        code, data = abl._req("GET", f"/fetcher/recipes?api={rezept.API_VERSION}")
    except OSError:
        erg.erreichbar = False
        return erg
    if code != 200 or not isinstance(data, dict):
        erg.erreichbar = code < 500   # 404 = this Kalmido has no recipe route yet: nothing to do
        return erg
    jetzt = rezept.available(ziel, schluessel=schluessel)
    for item in data.get("recipes") or []:
        if not isinstance(item, dict):
            continue
        rid = str(item.get("id") or "")
        if not ID_RE.fullmatch(rid):
            erg.abgelehnt.append((rid[:40] or "?", "ungültiger Name"))
            continue
        try:
            if int(item.get("api") or 0) != rezept.API_VERSION:
                continue
        except (TypeError, ValueError):
            continue
        cur = jetzt.get(rid)
        if cur is not None and rezept.vkey(str(item.get("version"))) <= rezept.vkey(cur.VERSION):
            continue
        quelle = str(item.get("source") or "").encode("utf-8")
        sig = {k: item.get(k) for k in ("id", "version", "api", "sha256", "key", "sig")}
        try:
            meta = signatur.pruefen(quelle, sig, schluessel)
        except signatur.SignaturFehler as e:
            erg.abgelehnt.append((rid, str(e)))
            log.warning("Rezept %s abgelehnt: %s", rid, e)
            continue
        if meta["id"] != rid:
            erg.abgelehnt.append((rid, "Signatur gehört zu einem anderen Portal"))
            continue
        alt = _sichern(ziel, rid)
        _ablegen(ziel, rid, quelle, sig)
        try:   # loads (and checks) it the way a run will; a file that does not load is taken back out
            cls = rezept.laden(ziel / f"{rid}.py", True, schluessel)
        except Exception as e:  # noqa: BLE001 - whatever it is, this version must not stay
            _entfernen(ziel, rid)
            if alt:
                _ablegen(ziel, rid, alt[0], alt[1])   # the delivered version before stays in force
            erg.abgelehnt.append((rid, f"lädt nicht ({type(e).__name__})"))
            continue
        erg.neu.append((rid, cls.VERSION))
        log.info("Rezept %s %s aus Kalmido übernommen", rid, cls.VERSION)
    return erg


def _ablegen(ziel: Path, rid: str, quelle: bytes, sig: dict):
    ziel.mkdir(parents=True, exist_ok=True)
    py, sj = ziel / f"{rid}.py", signatur.sig_datei(ziel / f"{rid}.py")
    # the signature first: between the two replaces the loader sees either the old pair or a new .sig with the old
    # .py (sha mismatch = skipped for that moment), never unsigned new code
    for path, data in ((sj, json.dumps(sig, indent=1).encode()), (py, quelle)):
        tmp = path.with_name("." + path.name + ".part")
        tmp.write_bytes(data)
        os.replace(tmp, path)


def _sichern(ziel: Path, rid: str):
    py = ziel / f"{rid}.py"
    try:
        return py.read_bytes(), json.loads(signatur.sig_datei(py).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None


def _entfernen(ziel: Path, rid: str):
    for p in (ziel / f"{rid}.py", signatur.sig_datei(ziel / f"{rid}.py")):
        p.unlink(missing_ok=True)
