"""State per portal account: which invoices were fetched (key + file hash) and which orders still lack an invoice.

<settings>/zustand/<portal>-<konto>.json:
  {"geholt": {key: {"sha256", "datei", "datum", "am"}},
   "ohne_rechnung": {key: {"datum", "zuerst", "zuletzt", "versuche"}},
   "erster_lauf": "YYYY-MM-DD" | null, "letzter_lauf": ISO}
"""
import json
import os
from datetime import date, datetime, timedelta
from pathlib import Path


class Zustand:
    def __init__(self, path: Path):
        self.path = path
        self.data = {"geholt": {}, "ohne_rechnung": {}, "erster_lauf": None, "letzter_lauf": None}
        if path.exists():
            self.data.update(json.loads(path.read_text(encoding="utf-8")))
        self._hashes = {v.get("sha256") for v in self.data["geholt"].values()}

    def save(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.path.with_suffix(".json.tmp")
        tmp.write_text(json.dumps(self.data, ensure_ascii=False, indent=1, sort_keys=True) + "\n", encoding="utf-8")
        os.chmod(tmp, 0o600)
        os.replace(tmp, self.path)

    def geholt(self, key: str) -> bool:
        return key in self.data["geholt"]

    def hash_bekannt(self, sha: str) -> bool:
        return sha in self._hashes

    def merke_geholt(self, key: str, sha: str, datei: str, datum: date):
        self.data["geholt"][key] = {"sha256": sha, "datei": datei, "datum": datum.isoformat(),
                                    "am": datetime.now().isoformat(timespec="seconds")}
        self._hashes.add(sha)
        self.data["ohne_rechnung"].pop(key, None)

    def merke_ohne_rechnung(self, key: str, datum: date):
        now = datetime.now().isoformat(timespec="seconds")
        e = self.data["ohne_rechnung"].setdefault(key, {"datum": datum.isoformat(), "zuerst": now, "versuche": 0})
        e["zuletzt"] = now
        e["versuche"] = e.get("versuche", 0) + 1

    def offen(self):
        return dict(self.data["ohne_rechnung"])

    def aufgeben(self, tage: int, heute=None) -> int:
        """Stop checking orders first noticed without an invoice more than `tage` days ago. Returns how many."""
        heute = heute or date.today()
        weg = [k for k, e in self.data["ohne_rechnung"].items()
               if date.fromisoformat(e.get("zuerst", e["datum"])[:10]) < heute - timedelta(days=tage)]
        for k in weg:
            self.data["ohne_rechnung"].pop(k)
        return len(weg)

    def seit(self, jahre: int, heute=None) -> date:
        """From when to look: first run = Jan 1 of (current year - jahre + 1); later runs: the oldest still open order,
        but at most 40 days back (orders older than that and not open are done)."""
        heute = heute or date.today()
        if not self.data.get("erster_lauf"):
            return date(heute.year - max(1, int(jahre)) + 1, 1, 1)
        start = heute - timedelta(days=40)
        for e in self.data["ohne_rechnung"].values():
            d = date.fromisoformat(e["datum"])
            if d < start:
                start = d
        return start

    def lauf_fertig(self):
        now = datetime.now().isoformat(timespec="seconds")
        if not self.data.get("erster_lauf"):
            self.data["erster_lauf"] = now[:10]
        self.data["letzter_lauf"] = now
