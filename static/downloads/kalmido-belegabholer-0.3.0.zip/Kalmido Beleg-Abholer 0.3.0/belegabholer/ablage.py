"""The delivery layer: where a fetched PDF goes. Exchangeable (decision 27.10.2026):

  ordner   (now)   write the PDF into a folder, by default the one the Kalmido folder watcher uploads from
  kalmido  (#3453, since 0.2.0) upload directly to Kalmido with the key from a setup code and report the state per portal

Every Ablage has abgeben(pdf, name, meta) -> where it went (for the status, no personal data in logs) and
status(bericht) (the per-portal report: last run, new invoices, errors; the folder variant keeps it in status.json).
"""
import base64
import json
import logging
import os
import re
import time
import urllib.error
import urllib.request
import uuid
from datetime import datetime
from pathlib import Path

from . import __version__, einstellungen

log = logging.getLogger("belegabholer")


def dateiname(datum, portal_name: str, nummer: str, art: str = "Rechnung") -> str:
    """Datum_Portal_Nummer.pdf, e.g. 2026-10-03_Amazon_302-1234567-1234567.pdf (credit notes: ..._Gutschrift.pdf)."""
    nr = re.sub(r"[^A-Za-z0-9._-]+", "-", nummer).strip("-.") or "ohne-Nummer"
    portal = re.sub(r"[^A-Za-z0-9-]+", "-", portal_name).strip("-")
    tail = "_Gutschrift" if art == "Gutschrift" else ""
    return f"{datum.isoformat()}_{portal}_{nr}{tail}.pdf"


class Ablage:
    name = ""

    def abgeben(self, pdf: bytes, name: str, meta: dict) -> str:
        raise NotImplementedError

    def status(self, bericht: dict) -> None:
        """bericht: {"<portal>/<konto>": {"letzter_lauf", "ergebnis", "neu", "ohne_rechnung", "fehler", "rezept"}}"""
        p = einstellungen.status_file()
        p.parent.mkdir(parents=True, exist_ok=True)
        old = {}
        if p.exists():
            try:
                old = json.loads(p.read_text(encoding="utf-8"))
            except ValueError:
                old = {}
        old.update(bericht)
        tmp = p.with_suffix(".json.tmp")
        tmp.write_text(json.dumps(old, ensure_ascii=False, indent=1, sort_keys=True) + "\n", encoding="utf-8")
        os.replace(tmp, p)


class OrdnerAblage(Ablage):
    name = "ordner"

    def __init__(self, folder: Path):
        self.folder = Path(folder)

    def abgeben(self, pdf: bytes, name: str, meta: dict) -> str:
        self.folder.mkdir(parents=True, exist_ok=True)
        target = self.folder / name
        stem, n = target.stem, 2
        while target.exists() or (self.folder / "Hochgeladen" / target.name).exists():
            target = self.folder / f"{stem} ({n}).pdf"
            n += 1
        # hidden partial name first: the folder watcher ignores ".*" and "*.part", so it never sees half a file
        tmp = self.folder / f".{target.name}.part"
        tmp.write_bytes(pdf)
        os.replace(tmp, target)
        return str(target)


class AblageFehler(Exception):
    """The delivery refused for good (not a network hiccup): art = "verbindung" (key unknown / disconnected / no office
    any more: connect again) or "aus" (the portal is switched off in Kalmido: skip it, fetch nothing)."""

    def __init__(self, art: str, text: str):
        super().__init__(text)
        self.art = art


def setup_code_lesen(code: str) -> dict:
    """kalmido-fetch:1:<base64url of {"url", "key", "name"}> -> {"url", "key", "name"} (ValueError if broken)."""
    code = "".join((code or "").split())
    prefix = "kalmido-fetch:1:"
    if not code.startswith(prefix):
        raise ValueError("Das ist kein Einrichtungscode (er beginnt mit kalmido-fetch:1:).")
    raw = code[len(prefix):]
    try:
        data = json.loads(base64.urlsafe_b64decode(raw + "=" * (-len(raw) % 4)).decode("utf-8"))
    except Exception:
        raise ValueError("Der Einrichtungscode ist unvollständig. Bitte ganz kopieren.")
    url, key = str(data.get("url") or "").rstrip("/"), str(data.get("key") or "")
    if not re.fullmatch(r"https?://[^\s/]+(/[^\s]*)?", url) or not re.fullmatch(r"kbh_[A-Za-z0-9_-]{20,100}", key):
        raise ValueError("Der Einrichtungscode ist unvollständig. Bitte ganz kopieren.")
    if url.startswith("http://") and not re.match(r"http://(localhost|127\.0\.0\.1)(:|/|$)", url):
        raise ValueError("Der Einrichtungscode nennt keine sichere Adresse (https).")
    return {"url": url, "key": key, "name": str(data.get("name") or "")[:80]}


def verbindung_laden():
    p = einstellungen.kalmido_file()
    try:
        d = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    return d if d.get("url") and d.get("key") else None


def verbindung_speichern(d: dict) -> None:
    p = einstellungen.kalmido_file()
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(".json.tmp")
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        json.dump(d, f, ensure_ascii=False, indent=1)
    os.replace(tmp, p)
    os.chmod(p, 0o600)


def portal_key(portal: str, konto: str) -> str:
    """The key Kalmido knows the portal by: amazon, a second account amazon.zweit (a-z 0-9 _ . -, up to 40)."""
    k = portal if konto == "standard" else f"{portal}.{konto}"
    return (re.sub(r"[^a-z0-9_.-]+", "-", k.lower()).strip("-.") or "portal")[:40]


FEHLER_TEXT = {  # what Kalmido shows the person next to the portal (German, as the helper speaks German)
    "anmeldung": "Bitte neu einloggen: {login}",
    "kaputt": "Rezept {rezept} passt nicht mehr - Prüfen mit: belegabholer run {portal} --sichtbar",
    "fehler": "Unerwarteter Fehler ({fehler}) - Prüfen mit: belegabholer run {portal} --sichtbar",
}


class KalmidoAblage(Ablage):
    """Direct upload to Kalmido (#3453): POST /api/v1/fetcher/documents with the helper's own key (kbh_...), the state
    per portal with PUT /api/v1/fetcher/status. Kalmido never gets passwords, cookies or logins - only PDFs and state.
    A network hiccup / server error keeps the PDF in <settings>/warteschlange and sends it on the next run (the
    state already counts it as fetched, so nothing is lost and nothing fetched twice)."""
    name = "kalmido"
    TIMEOUT = 60

    def __init__(self, cfg: dict, verbindung: dict = None):
        self.cfg = cfg
        self.v = verbindung or verbindung_laden()
        if not self.v:
            raise AblageFehler("verbindung", "Nicht mit Kalmido verbunden: belegabholer verbinden <Einrichtungscode>")
        self.api = self.v["url"].rstrip("/") + "/api/v1"
        self._portale = None
        self.status_ok = False    # the last state report reached Kalmido (then Kalmido notifies the person itself)
        self.in_warteschlange = 0

    # ---- HTTP ----
    def _req(self, method: str, path: str, body: bytes = None, ctype: str = None, retry: bool = True):
        req = urllib.request.Request(self.api + path, data=body, method=method)
        req.add_header("Authorization", "Bearer " + self.v["key"])
        req.add_header("Accept", "application/json")
        req.add_header("User-Agent", f"kalmido-belegabholer/{__version__}")
        if ctype:
            req.add_header("Content-Type", ctype)
        try:
            with urllib.request.urlopen(req, timeout=self.TIMEOUT) as r:
                return r.status, _json(r.read())
        except urllib.error.HTTPError as e:
            data = _json(e.read())
            if e.code == 429 and retry:
                try:
                    wait = min(max(int(e.headers.get("Retry-After") or 60), 1), 120)
                except ValueError:
                    wait = 60
                time.sleep(wait)
                return self._req(method, path, body, ctype, retry=False)
            return e.code, data

    @staticmethod
    def _fehler(code: int, data: dict):
        msg = str((data or {}).get("error") or (data or {}).get("detail") or "")[:200]
        if code == 401:
            raise AblageFehler("verbindung", "Kalmido kennt diesen Abholer nicht mehr (getrennt, abgelaufen oder "
                                             "Passwort geändert). Neu verbinden: belegabholer verbinden <Einrichtungscode>")
        if code == 403:
            raise AblageFehler("verbindung", "Kalmido nimmt keine Belege mehr an" + (f" ({msg})" if msg else "")
                               + ". Neu verbinden: belegabholer verbinden <Einrichtungscode>")

    def pruefen(self) -> dict:
        """GET /fetcher: {name, target, max_mb, portals}. Raises AblageFehler on 401/403, OSError when unreachable."""
        code, data = self._req("GET", "/fetcher")
        self._fehler(code, data)
        if code != 200:
            raise OSError(f"Kalmido antwortet {code}")
        self._portale = {p.get("key"): bool(p.get("enabled")) for p in data.get("portals") or [] if isinstance(p, dict)}
        return data

    def freigegeben(self, portal: str, konto: str) -> bool:
        """False only if Kalmido knows the portal and it is switched off there; unknown = new = on."""
        if self._portale is None:
            try:
                self.pruefen()
            except OSError:
                return True   # unreachable: fetch anyway, the PDFs wait in the queue
        return self._portale.get(portal_key(portal, konto), True)

    # ---- delivery ----
    def abgeben(self, pdf: bytes, name: str, meta: dict) -> str:
        key = portal_key(meta.get("portal") or "portal", meta.get("konto") or "standard")
        try:
            return self._hochladen(pdf, name, key, meta.get("nummer") or "")
        except OSError:
            self._einreihen(pdf, name, key, meta.get("nummer") or "")
            return "warteschlange"

    def _hochladen(self, pdf: bytes, name: str, key: str, nummer: str) -> str:
        if self._portale is not None and key not in self._portale:
            self._melden([{"key": key}])   # a new portal must be reported before its first upload
        felder = {"portal": key}
        if nummer:
            felder["order"] = nummer[:100]
        body, ctype = _multipart(felder, "file", name, pdf)
        code, data = self._req("POST", "/fetcher/documents", body, ctype)
        if code == 400 and "portal" in str(data).lower():   # Kalmido does not know the portal yet: report, then again
            self._melden([{"key": key}])
            code, data = self._req("POST", "/fetcher/documents", body, ctype)
        self._fehler(code, data)
        if code == 409:
            raise AblageFehler("aus", "In Kalmido ausgeschaltet")
        if code in (200, 201):
            return f"kalmido:{(data or {}).get('id', '?')}" + (":doppelt" if (data or {}).get("duplicate") else "")
        raise OSError(f"Kalmido antwortet {code}")   # 413 / 429 / 5xx: keep it, try again next run

    def _einreihen(self, pdf: bytes, name: str, key: str, nummer: str):
        q = einstellungen.queue_dir()
        q.mkdir(parents=True, exist_ok=True)
        os.chmod(q, 0o700)
        stem = Path(name).stem
        target, n = q / name, 2
        while target.exists():
            target = q / f"{stem} ({n}).pdf"
            n += 1
        tmp = q / f".{target.name}.part"
        tmp.write_bytes(pdf)
        target.with_suffix(".json").write_text(json.dumps({"portal": key, "nummer": nummer, "name": name}), encoding="utf-8")
        os.replace(tmp, target)
        self.in_warteschlange += 1
        log.warning("Kalmido nicht erreichbar: Beleg in der Warteschlange")

    def nachreichen(self) -> tuple:
        """Send the queued PDFs (oldest first). -> (sent, still waiting). Stops at the first network error."""
        q = einstellungen.queue_dir()
        files = sorted(q.glob("*.pdf"), key=lambda p: p.stat().st_mtime) if q.exists() else []
        sent = 0
        for i, f in enumerate(files):
            meta_p = f.with_suffix(".json")
            try:
                meta = json.loads(meta_p.read_text(encoding="utf-8"))
            except (OSError, ValueError):
                meta = {"portal": "portal", "nummer": "", "name": f.name}
            try:
                self._hochladen(f.read_bytes(), meta.get("name") or f.name, meta.get("portal") or "portal",
                                meta.get("nummer") or "")
            except OSError:
                return sent, len(files) - i
            except AblageFehler as e:
                if e.art == "aus":     # switched off in Kalmido: it stays in the queue until switched on again
                    continue
                raise
            f.unlink(missing_ok=True)
            meta_p.unlink(missing_ok=True)
            sent += 1
        left = len(list(q.glob("*.pdf"))) if q.exists() else 0
        return sent, left

    # ---- state ----
    def _melden(self, portals: list) -> bool:
        body = json.dumps({"portals": portals}).encode()
        code, data = self._req("PUT", "/fetcher/status", body, "application/json")
        self._fehler(code, data)
        if code != 200:
            raise OSError(f"Kalmido antwortet {code}")
        self._portale = {p.get("key"): bool(p.get("enabled")) for p in (data or {}).get("portals") or []
                         if isinstance(p, dict)}
        return True

    def status(self, bericht: dict) -> None:
        super().status(bericht)    # the local status.json stays (belegabholer status)
        portals = []
        for pk, s in bericht.items():
            portal, _, konto = pk.partition("/")
            konto = konto or "standard"
            if s.get("ergebnis") in ("belegt", "aus"):
                continue           # nothing ran: no news for Kalmido
            fehler = ""
            vorlage = FEHLER_TEXT.get(s.get("ergebnis"))
            if vorlage:
                login = "belegabholer login " + portal + ("" if konto == "standard" else f" --konto {konto}")
                fehler = vorlage.format(login=login, rezept=s.get("rezept", ""), portal=portal,
                                        fehler=s.get("fehler", ""))[:200]
            name = (s.get("name") or portal) + ("" if konto == "standard" else f" ({konto})")
            last = s.get("letzter_lauf")
            if last and not re.search(r"(Z|[+-]\d\d:?\d\d)$", last):
                last = datetime.fromisoformat(last).astimezone().isoformat(timespec="seconds")
            portals.append({"key": portal_key(portal, konto), "name": name[:80], "last_run": last,
                            "new": int(s.get("neu") or 0), "error": fehler})
        if not portals:
            return
        try:
            self.status_ok = self._melden(portals)
        except OSError:
            self.status_ok = False
            log.warning("Status nicht an Kalmido gemeldet (nicht erreichbar)")


def _json(raw: bytes):
    try:
        return json.loads(raw.decode("utf-8") or "{}")
    except (ValueError, UnicodeDecodeError):
        return {}


def _multipart(fields: dict, file_field: str, filename: str, content: bytes):
    boundary = "----belegabholer" + uuid.uuid4().hex
    out = bytearray()
    for k, v in fields.items():
        out += (f"--{boundary}\r\nContent-Disposition: form-data; name=\"{k}\"\r\n\r\n{v}\r\n").encode()
    safe = re.sub(r'["\r\n\\]', "_", filename)
    out += (f"--{boundary}\r\nContent-Disposition: form-data; name=\"{file_field}\"; filename=\"{safe}\"\r\n"
            f"Content-Type: application/pdf\r\n\r\n").encode()
    out += content + f"\r\n--{boundary}--\r\n".encode()
    return bytes(out), f"multipart/form-data; boundary={boundary}"


def make(cfg: dict) -> Ablage:
    kind = cfg.get("ablage") or "ordner"
    if kind == "ordner":
        folder, _ = einstellungen.output_dir(cfg)
        return OrdnerAblage(folder)
    if kind == "kalmido":
        return KalmidoAblage(cfg)
    raise ValueError(f"unbekannte Ablage {kind!r}")
