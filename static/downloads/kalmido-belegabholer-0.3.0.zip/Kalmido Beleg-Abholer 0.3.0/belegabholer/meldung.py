"""Notifications when a login expired or a recipe broke: ntfy (like kalmido-ntfy.sh) and/or a system notification
(Mac banner, Windows toast; settings value "system", the old value "mac" means the same).

ntfy needs <settings>/ntfy.env (mode 600) with NTFY_URL, NTFY_TOPIC and NTFY_OPS_TOKEN (or NTFY_TOKEN). Texts carry
no personal data: portal, account name and the command to fix it.
"""
import logging
import urllib.request

from . import einstellungen, plattform

log = logging.getLogger("belegabholer")


def _env(path):
    out = {}
    try:
        for line in path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                out[k.strip().removeprefix("export ").strip()] = v.strip().strip('"').strip("'")
    except OSError:
        pass
    return out


def ntfy(titel: str, text: str) -> bool:
    env = _env(einstellungen.home() / "ntfy.env")
    url, topic = env.get("NTFY_URL"), env.get("NTFY_TOPIC")
    token = env.get("NTFY_TOKEN") or env.get("NTFY_OPS_TOKEN")
    if not (url and topic):
        return False
    req = urllib.request.Request(url.rstrip("/") + "/" + topic, data=text.encode("utf-8"), method="POST")
    # ntfy wants header values in latin-1; umlauts in the title go as RFC 2047 so they arrive intact
    req.add_header("Title", "=?UTF-8?B?" + __import__("base64").b64encode(titel.encode()).decode() + "?=")
    req.add_header("Priority", "4")
    req.add_header("Tags", "kalmido,receipt")
    if token:
        req.add_header("Authorization", "Bearer " + token)
    try:
        urllib.request.urlopen(req, timeout=20).read()
        return True
    except Exception as e:  # never fail the run because of the notification
        log.warning("ntfy nicht gesendet: %s", type(e).__name__)
        return False


def system(titel: str, text: str) -> bool:
    return plattform.mitteilung(titel, text)


mac = system   # older name


def senden(cfg: dict, titel: str, text: str, ohne=()):
    """ohne: ways to leave out, e.g. ("ntfy",) when Kalmido already tells the person (the state report reached it)."""
    wege = [w for w in (cfg.get("meldung") or []) if w not in ohne]
    sent = []
    if "ntfy" in wege and ntfy(titel, text):
        sent.append("ntfy")
    if ("system" in wege or "mac" in wege) and system(titel, text):
        sent.append("system")
    log.info("Meldung \"%s\" über %s", titel, ", ".join(sent) or "keinen Weg")
    return sent
