"""The run of one portal account: open the profile, check the login, walk the recipe's invoices, deliver the new ones.

Logs only counts and portal / account names, never order numbers, amounts or file names.
"""
import hashlib
import logging
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta

from . import ablage as ablage_mod, browser, einstellungen
from .rezept import AnmeldungAbgelaufen, Beleg, RezeptKaputt
from .zustand import Zustand

log = logging.getLogger("belegabholer")


@dataclass
class Ergebnis:
    portal: str
    konto: str
    rezept: str
    ergebnis: str = "ok"         # ok | anmeldung | kaputt | belegt | fehler | aus | verbindung
    name: str = ""
    neu: int = 0
    doppelt: int = 0
    ohne_rechnung: int = 0
    aufgegeben: int = 0
    vollstaendig: bool = True
    fehler: str = ""
    dateien: list = field(default_factory=list)

    def bericht(self):
        return {f"{self.portal}/{self.konto}": {
            "letzter_lauf": datetime.now().isoformat(timespec="seconds"), "ergebnis": self.ergebnis,
            "neu": self.neu, "ohne_rechnung": self.ohne_rechnung, "fehler": self.fehler, "rezept": self.rezept,
            "name": self.name}}


def zustand_fuer(portal: str, konto: str) -> Zustand:
    return Zustand(einstellungen.state_dir() / f"{portal}-{konto}.json")


def lauf(cls, konto: str, cfg: dict, ablage=None, sichtbar: bool = False, max_neu: int = None) -> Ergebnis:
    portal_cfg = (cfg.get("portale") or {}).get(cls.ID) or {}
    rez = cls(cfg, portal_cfg)
    erg = Ergebnis(cls.ID, konto, f"{cls.ID} {cls.VERSION}", name=cls.NAME)
    ablage = ablage or ablage_mod.make(cfg)
    try:
        if hasattr(ablage, "freigegeben") and not ablage.freigegeben(cls.ID, konto):
            erg.ergebnis, erg.fehler = "aus", "in Kalmido ausgeschaltet"
            log.info("%s/%s: in Kalmido ausgeschaltet, übersprungen", cls.ID, konto)
            return erg
    except ablage_mod.AblageFehler as e:
        erg.ergebnis, erg.fehler = e.art, str(e)[:200]
        return erg
    z = zustand_fuer(cls.ID, konto)
    seit = z.seit(cfg.get("erster_lauf_jahre", 2))
    max_neu = max_neu if max_neu is not None else int(cfg.get("max_neu_pro_lauf", 120))
    heute = date.today()
    offen = z.offen()

    def erledigt(gruppe: str, datum: date) -> bool:
        """Skip an order already fetched, unless it is young (a later partial invoice may still come) or open."""
        if gruppe in offen:
            return False
        if datum >= heute - timedelta(days=14):
            return False
        return any(k == gruppe or k.startswith(gruppe + "#") for k in z.data["geholt"])

    try:
        with browser.profil(einstellungen.profile_dir(cls.ID, konto), sichtbar=sichtbar, kanal=browser.kanal(cls, cfg)) as ctx:
            page = browser.erste_seite(ctx)
            if not rez.angemeldet(page):
                raise AnmeldungAbgelaufen("nicht angemeldet")
            letzte_gruppe = None
            for b in rez.belege(page, seit, erledigt):
                b: Beleg
                if z.geholt(b.schluessel):
                    continue
                if b.url is None:
                    z.merke_ohne_rechnung(b.gruppe or b.schluessel, b.datum)
                    continue
                if erg.neu >= max_neu and (not b.gruppe or b.gruppe != letzte_gruppe):
                    erg.vollstaendig = False  # stop only between orders, never inside one
                    break
                letzte_gruppe = b.gruppe
                pdf = rez.laden(page, b)
                if not pdf.startswith(b"%PDF"):
                    raise RezeptKaputt("Download ist kein PDF")
                sha = hashlib.sha256(pdf).hexdigest()
                if z.hash_bekannt(sha):
                    z.merke_geholt(b.schluessel, sha, "", b.datum)
                    erg.doppelt += 1
                else:
                    name = ablage_mod.dateiname(b.datum, cls.NAME, b.nummer, b.art)
                    wo = ablage.abgeben(pdf, name, {"portal": cls.ID, "konto": konto, "datum": b.datum.isoformat(),
                                                         "nummer": b.nummer})
                    z.merke_geholt(b.schluessel, sha, name, b.datum)
                    erg.neu += 1
                    erg.dateien.append(wo)
                if b.gruppe:
                    z.data["ohne_rechnung"].pop(b.gruppe, None)
                z.save()
    except AnmeldungAbgelaufen as e:
        erg.ergebnis, erg.fehler = "anmeldung", str(e)[:200]
    except RezeptKaputt as e:
        erg.ergebnis, erg.fehler = "kaputt", str(e)[:200]
    except ablage_mod.AblageFehler as e:   # Kalmido refused for good: the PDF was NOT taken, so not marked fetched
        erg.ergebnis, erg.fehler = e.art, str(e)[:200]
    except browser.ProfilBelegt:
        erg.ergebnis, erg.fehler = "belegt", "Browserprofil ist gerade offen (Login-Fenster?)"
    except Exception as e:  # anything else: a broken recipe until proven otherwise; type only, no page content
        erg.ergebnis, erg.fehler = "fehler", type(e).__name__
        log.exception("%s/%s: unerwarteter Fehler", cls.ID, konto)
    erg.aufgegeben = z.aufgeben(int(cfg.get("ohne_rechnung_tage", 60)))
    erg.ohne_rechnung = len(z.data["ohne_rechnung"])
    if erg.ergebnis == "ok" and erg.vollstaendig:
        z.lauf_fertig()
    z.save()
    log.info("%s/%s (Rezept %s): %s, neu %d, doppelt %d, ohne Rechnung %d, aufgegeben %d%s", cls.ID, konto,
             cls.VERSION, erg.ergebnis, erg.neu, erg.doppelt, erg.ohne_rechnung, erg.aufgegeben,
             "" if erg.vollstaendig else ", Rest in der nächsten Nacht")
    try:
        ablage.status(erg.bericht())
    except Exception:
        log.warning("Status nicht geschrieben")
    return erg
