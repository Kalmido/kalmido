"""Kalmido Beleg-Abholer: holt Rechnungen aus Web-Portalen mit einem lokalen, dauerhaften Browserprofil.

Logins bleiben auf diesem Rechner; das Werkzeug speichert keine Passwörter. Jedes Portal ist ein Rezept
(belegabholer/rezepte/<id>.py) mit Versionsnummer; neuere Rezepte können später zentral verteilt werden und
liegen dann im Einstellungsordner unter rezepte/.
"""

__version__ = "0.3.0"
