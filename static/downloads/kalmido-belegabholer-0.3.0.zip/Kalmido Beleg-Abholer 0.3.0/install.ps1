# Kalmido Beleg-Abholer - install / update for the CURRENT Windows user (no admin rights needed), #3454.
# Program + Python environment: %LOCALAPPDATA%\Kalmido Beleg-Abholer (app, venv, bin); settings, browser profiles and
# state: %APPDATA%\Kalmido Beleg-Abholer (see belegabholer/einstellungen.py). Puts "belegabholer" into the user's PATH.
# Running it again = update (profiles, state and settings stay). Start: Einrichten.cmd (double-click).
param([switch]$Einrichten)
$ErrorActionPreference = 'Stop'
$Src = $PSScriptRoot
$App = Join-Path $env:LOCALAPPDATA 'Kalmido Beleg-Abholer'
$Settings = Join-Path $env:APPDATA 'Kalmido Beleg-Abholer'
$Bin = Join-Path $App 'bin'
New-Item -ItemType Directory -Force -Path $App, $Settings, $Bin | Out-Null

function Find-Python {
    foreach ($v in '3.13', '3.12', '3.11', '3.10') {
        try {
            $p = & py "-$v" -c "import sys; print(sys.executable)" 2>$null
            if ($LASTEXITCODE -eq 0 -and $p) { return $p.Trim() }
        } catch {}
    }
    try {   # "python" can be the Microsoft Store alias: it prints nothing then
        $p = & python -c "import sys; print(sys.executable if sys.version_info >= (3, 10) else '')" 2>$null
        if ($LASTEXITCODE -eq 0 -and $p) { return $p.Trim() }
    } catch {}
    return $null
}

$Py = Find-Python
if (-not $Py) {
    Write-Host "0/4 Kein Python ab 3.10 gefunden - lade eins nur fuer diesen Benutzer (uv, einmalig gut 50 MB)"
    $Uv = Join-Path $App 'uv\uv.exe'
    if (-not (Test-Path $Uv)) {
        $env:UV_INSTALL_DIR = Join-Path $App 'uv'
        $env:UV_NO_MODIFY_PATH = '1'
        Invoke-RestMethod https://astral.sh/uv/install.ps1 | Invoke-Expression | Out-Null
    }
    $env:UV_PYTHON_INSTALL_DIR = Join-Path $App 'python'
    & $Uv python install 3.12 | Out-Null
    $Py = (& $Uv python find 3.12).Trim()
}
if (-not $Py) { Write-Host "Kein Python gefunden. Bitte Python 3.12 von python.org installieren."; exit 1 }

Write-Host "1/4 Programm kopieren"
$New = Join-Path $App 'app.new'
if (Test-Path $New) { Remove-Item -Recurse -Force $New }
New-Item -ItemType Directory -Path $New | Out-Null
Copy-Item -Recurse (Join-Path $Src 'belegabholer') $New
Copy-Item (Join-Path $Src 'requirements.txt'), (Join-Path $Src 'README.md') $New
Get-ChildItem -Recurse -Directory -Filter __pycache__ $New | Remove-Item -Recurse -Force
$Cur = Join-Path $App 'app'
if (Test-Path $Cur) { Remove-Item -Recurse -Force $Cur }
Rename-Item $New 'app'

Write-Host "2/4 Python-Umgebung mit Playwright"
$VPy = Join-Path $App 'venv\Scripts\python.exe'
if (-not (Test-Path $VPy)) { & $Py -m venv (Join-Path $App 'venv') }
& $VPy -m pip install -q --upgrade pip
& $VPy -m pip install -q -r (Join-Path $Cur 'requirements.txt')
if ($LASTEXITCODE -ne 0) { Write-Host "pip ist fehlgeschlagen."; exit 1 }

Write-Host "3/4 Chromium fuer Playwright (einmalig gut 150 MB)"
& $VPy -m playwright install chromium | Out-Null

Write-Host "4/4 Befehl 'belegabholer' und Nachtlauf"
$Cmd = Join-Path $Bin 'belegabholer.cmd'
Set-Content -Encoding ASCII -Path $Cmd -Value @(
    '@echo off',
    "set `"PYTHONPATH=$Cur`"",
    "set `"PYTHONIOENCODING=utf-8`"",
    "`"$VPy`" -m belegabholer %*"
)
$UserPath = [Environment]::GetEnvironmentVariable('Path', 'User')
if (-not (($UserPath -split ';') -contains $Bin)) {
    [Environment]::SetEnvironmentVariable('Path', ((@($UserPath, $Bin) | Where-Object { $_ }) -join ';'), 'User')
}
if (-not (($env:Path -split ';') -contains $Bin)) { $env:Path = "$env:Path;$Bin" }
# ntfy for "please log in again" pushes, handed over next to this script (only if there is none yet)
$Ntfy = Join-Path $Src 'ntfy.env'
if ((Test-Path $Ntfy) -and -not (Test-Path (Join-Path $Settings 'ntfy.env'))) { Copy-Item $Ntfy $Settings }
& $Cmd nachtlauf an
if ($LASTEXITCODE -ne 0) { Write-Host "Nachtlauf noch aus (spaeter: belegabholer nachtlauf an)" }

if ($Einrichten) {
    & $Cmd einrichten
} else {
    Write-Host ""
    Write-Host "Fertig. Weiter mit: belegabholer einrichten   (in einem neuen Fenster)"
}
