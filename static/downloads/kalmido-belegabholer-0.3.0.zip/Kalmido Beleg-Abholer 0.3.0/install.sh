#!/bin/bash
# Kalmido Beleg-Abholer - install / update for the CURRENT Mac user (no admin rights needed).
# Copies the program into ~/Library/Application Support/Kalmido Beleg-Abholer/app, builds its own venv there
# (Playwright + Chromium), puts the command "belegabholer" into ~/.local/bin and switches the night run on.
# Running it again = update (profiles, state and settings stay).
set -euo pipefail
SRC="$(cd "$(dirname "$0")" && pwd)"
APP="$HOME/Library/Application Support/Kalmido Beleg-Abholer"
BIN="$HOME/.local/bin"

PY=""
for c in /usr/local/bin/python3.12 /opt/homebrew/bin/python3.12 /usr/local/bin/python3.13 /opt/homebrew/bin/python3.13 python3; do
  if command -v "$c" >/dev/null 2>&1 && "$c" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)' 2>/dev/null; then
    PY="$(command -v "$c")"; break
  fi
done
mkdir -p "$APP"; chmod 700 "$APP"
if [ -z "$PY" ]; then
  # no Python 3.10+ on this Mac (colleagues without developer tools): uv fetches one for this user only, no admin
  echo "0/4 Kein Python ab 3.10 gefunden - lade eins nur für diesen Benutzer (uv, einmalig gut 50 MB)"
  if [ ! -x "$APP/uv/uv" ]; then
    curl -LsSf https://astral.sh/uv/install.sh | env UV_INSTALL_DIR="$APP/uv" UV_NO_MODIFY_PATH=1 sh >/dev/null
  fi
  export UV_PYTHON_INSTALL_DIR="$APP/python"
  "$APP/uv/uv" python install 3.12 >/dev/null
  PY="$("$APP/uv/uv" python find 3.12)"
fi
[ -n "$PY" ] || { echo "Kein Python ab 3.10 gefunden (python.org-Installer oder Homebrew)."; exit 1; }

echo "1/4 Programm kopieren"
rm -rf "$APP/app.new"; mkdir -p "$APP/app.new"
cp -R "$SRC/belegabholer" "$SRC/requirements.txt" "$SRC/README.md" "$APP/app.new/"
find "$APP/app.new" -name __pycache__ -prune -exec rm -rf {} +
rm -rf "$APP/app"; mv "$APP/app.new" "$APP/app"

echo "2/4 Python-Umgebung mit Playwright ($("$PY" --version))"
[ -x "$APP/venv/bin/python" ] || "$PY" -m venv "$APP/venv"
"$APP/venv/bin/python" -m pip install -q --upgrade pip
"$APP/venv/bin/python" -m pip install -q -r "$APP/app/requirements.txt"

echo "3/4 Chromium für Playwright (einmalig gut 150 MB)"
"$APP/venv/bin/python" -m playwright install chromium >/dev/null

echo "4/4 Befehl 'belegabholer' und Nachtlauf"
mkdir -p "$BIN"
cat > "$BIN/belegabholer" <<EOF
#!/bin/bash
PYTHONPATH="$APP/app" exec "$APP/venv/bin/python" -m belegabholer "\$@"
EOF
chmod 755 "$BIN/belegabholer"
case ":$PATH:" in *":$BIN:"*) ;; *)
  grep -qs 'kalmido-belegabholer' "$HOME/.zprofile" || \
    printf '\nexport PATH="$HOME/.local/bin:$PATH"  # kalmido-belegabholer\n' >> "$HOME/.zprofile" ;;
esac
# ntfy for "please log in again" pushes: handed over next to this script, readable only for this user
if [ -r "$SRC/ntfy.env" ] && [ ! -e "$APP/ntfy.env" ]; then
  cp "$SRC/ntfy.env" "$APP/ntfy.env"; chmod 600 "$APP/ntfy.env"
fi
"$BIN/belegabholer" nachtlauf an || echo "Nachtlauf noch aus (später: belegabholer nachtlauf an)"

echo
echo "Fertig. Nächste Schritte:"
echo "  1. ~/.local/bin/belegabholer login amazon      (einmal je Portal, im sichtbaren Browser anmelden)"
echo "  2. ~/.local/bin/belegabholer verbinden         (Einrichtungscode aus Kalmido: Einstellungen > Integrationen > Beleg-Abholer)"
echo "  3. ~/.local/bin/belegabholer run               (erster Abruf jetzt, danach jede Nacht von selbst)"
echo "(in einem neuen Terminal-Fenster reicht: belegabholer ...)"
